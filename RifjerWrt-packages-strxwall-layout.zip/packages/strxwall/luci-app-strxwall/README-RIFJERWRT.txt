RifjerWrt local package recipe: luci-app-strxwall 2.5.53
Target: Arcadyan AW1000 Hardware V1 / aarch64_cortex-a53

This archive contains the data payload extracted from the user-provided
STRXWALL 2.5.53 package and an OpenWrt package Makefile.

The workflow extracts this archive and copies:
  packages/strxwall/luci-app-strxwall/
to:
  openwrt/package/strxwall/luci-app-strxwall/

The OpenWrt build system builds this package in the target package format.
Do not install the original IPK container directly on an APK-based image.

Safety changes in this RifjerWrt build recipe:
- STRXWALL DNS integration manages only dnsmasq 'server' and 'noresolv'.
- It never reads or writes dnsmasq 'extraconftext', AdBlock settings,
  AdBlock blocklists, or STRXWALL AdBlock markers.
- Invalid DNS backups are quarantined and cause a safe failure; no automatic
  fallback DNS, AdBlock cleanup, or speculative recovery is performed.
- If DNS forwarding was changed outside STRXWALL, current DNS is preserved
  and the recovery backup is retained. STRXWALL refuses to apply over an
  unresolved backup.
- Recovery backup is retained until the original DNS settings have been
  committed and dnsmasq has restarted successfully.
- The included init script retains the upstream disabled-state behavior:
  IPv6 guard sync removes a stale STRXWALL guard when enabled=0; it does not
  install a guard while STRXWALL is disabled.

The upstream package control scripts (preinst/postinst/prerm/postrm) are
intentionally excluded. This avoids running the upstream postinst actions
during image installation, including automatic service enabling and firewall
IPv6-guard setup. The included UCI default keeps STRXWALL disabled initially.

Build checks still required:
- Verify CONFIG_USE_APK=y in the final OpenWrt .config.
- Verify dns2socks and conntrack are available and selected.
- Confirm Kconfig retains luci-app-strxwall and its dependencies.
- Build the package and test LuCI, core execution, DNS apply/restore, external
  DNS-change conflict handling, and reboot behavior on Arcadyan AW1000 V1.
- Confirm STRXWALL remains OFF after first boot.

This archive is a build input, not a firmware image and not a directly
installable router package.
