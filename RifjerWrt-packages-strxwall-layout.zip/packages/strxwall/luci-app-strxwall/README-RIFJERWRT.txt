RifjerWrt local package recipe: luci-app-strxwall 2.5.53
Target: Arcadyan AW1000 Hardware V1 / aarch64_cortex-a53

This archive contains the data payload extracted from the user-provided
strxwall_arcadyan_V1_2.5.53.ipk and an OpenWrt package Makefile.

The workflow should extract this archive and copy:
  packages/strxwall/luci-app-strxwall/
to:
  openwrt/package/strxwall/luci-app-strxwall/

The package is built by the OpenWrt build system; the original .ipk container
is not installed directly. In an APK-based OpenWrt tree, the build system
produces the package in the target package format.

The upstream control scripts (preinst/postinst/prerm/postrm) are intentionally
not copied into this build recipe. This avoids running the original postinst
actions during installation, including automatic service enabling and
firewall IPv6-guard setup. The package's init script and UCI defaults remain
in the data payload; inspect/test boot behavior on AW1000 V1 before release.

Important pending validation before production compile:
- Verify CONFIG_USE_APK=y in the final .config.
- Verify dns2socks and conntrack are available and selected.
- Audit and patch usr/libexec/strxwall-dns so it never modifies AdBlock
  extraconftext/blocklists and never discards an unresolved DNS backup.
- Confirm STRXWALL remains OFF after first boot and that no unwanted firewall
  rules are applied while disabled.
- Test package build, LuCI, core execution, DNS restore, and reboot on device.

This archive is a build input, not a firmware image and not a directly
installable router package.
