RifjerWrt local package recipe: luci-app-strxwall 2.5.5
Target: aarch64_cortex-a53 (Arcadyan AW1000 Hardware V1 build)

This directory is a package recipe reconstructed from the user-supplied
luci-app-strxwall_2.5.5_aarch64_cortex-a53.ipk. The original data payload
and documentation are retained under files/.

Important behavior:
- /etc/config/strxwall is shipped with option enabled '0'.
- The init service may be called at boot, but its start_service checks that
  UCI option and returns without starting the core or adding routing rules.
- The init rc.d links allow the service to start on later boots if the user
  enables STRXWall from LuCI.
- This recipe builds a native OpenWrt package in the target's APK feed; it
  does not install the original .ipk into an APK-based image.

Build dependency note:
- The original package declares dns2socks. The selected build feeds must
  provide a dns2socks package, otherwise package dependency resolution/build
  will fail. The OpenWrt-Passwall/openwrt-passwall-packages feed contains a
  dns2socks package recipe; add that feed deliberately in the workflow.

Verification still required on the actual AW1000 V1:
- Confirm the target package architecture is aarch64_cortex-a53.
- Confirm STRXCore executes on the router (the bundled binary is static
  AArch64 ELF, but has not been run on the device here).
- Test LuCI navigation, firewall4/nftables behavior, DNS restoration,
  reboot behavior, and OFF/ON transitions before publishing firmware.

Do not deploy this package to AW1000 Ultra or other hardware without testing.
