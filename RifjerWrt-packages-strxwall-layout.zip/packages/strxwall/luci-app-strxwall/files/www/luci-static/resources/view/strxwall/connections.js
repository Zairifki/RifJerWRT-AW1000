'use strict';
'require view';
'require poll';
'require strxwall.common as sw';

return view.extend({
 render:function(){
  var enabled=false,busy=false,generation=0,rows=[];
  var status=E('p',{class:'sw-muted',role:'status'},'Live monitoring is paused.');
  var body=E('tbody');
  var filter=sw.input('');
  filter.placeholder='Filter by device or destination';
  filter.setAttribute('aria-label',filter.placeholder);
  var toggle=sw.toggle(false,'Live monitoring');
  var domains=sw.toggle(false,'Estimate domains');
  var reverse=sw.toggle(false,'Reverse DNS (IPv4)');
  var ptr=new Map(),ptrBusy=false;
  var hints=new Map();
  var dnsStatus=E('p',{class:'sw-muted',role:'status'});
  function remember(replies){
   var now=Date.now();
   hints.forEach(function(hint,key){if(hint.expires<=now)hints.delete(key);});
   (replies||[]).forEach(function(reply){
    var key=reply.client+'|'+reply.ip,previous=hints.get(key);
    var domain=previous&&previous.domain!==reply.domain?'':reply.domain;
    hints.delete(key);
    hints.set(key,{domain:domain,expires:now+120000});
   });
   while(hints.size>256)hints.delete(hints.keys().next().value);
  }
  function draw(){
   var query=filter.value.trim().toLowerCase();
   function domain(row){
    var hint=hints.get(row.source+'|'+row.destination);
    return hint&&hint.expires>Date.now()?hint.domain:'';
   }
   function hostname(row){
    var record=reverse.input.checked&&ptr.get(row.destination);
    return record&&record.expires>Date.now()?record.hostname:'';
   }
   var visible=rows.filter(function(row){
    return [row.device,row.source,row.destination,row.port,domain(row),hostname(row)].join(' ').toLowerCase().includes(query);
   });
   body.replaceChildren.apply(body,visible.map(function(row){
    var address=row.destination.includes(':')?'['+row.destination+']':row.destination;
    return E('tr',{},[
     E('td',{},[E('strong',{},row.device||row.source),row.device?E('div',{class:'sw-sub'},row.source):'']),
     E('td',{},address+':'+row.port),E('td',{},domain(row)?domain(row)+' (estimated)':hostname(row)?hostname(row)+' (PTR)':'—'),E('td',{},row.protocol)
    ]);
   }));
  }
  function lookup(){
   if(!enabled||!reverse.input.checked||ptrBusy||document.hidden)return;
   var row=rows.find(function(item){
    var record=ptr.get(item.destination);
    return /^\d+\.\d+\.\d+\.\d+$/.test(item.destination)&&(!record||record.expires<=Date.now());
   });
   if(!row)return;
   var current=generation,ip=row.destination;
   ptrBusy=true;
   return sw.api('connection_ptr',{ip:ip}).catch(function(){return {};}).then(function(result){
    if(current!==generation)return;
    ptr.delete(ip);
    ptr.set(ip,{hostname:result.hostname,expires:Date.now()+300000});
    if(ptr.size>256)ptr.delete(ptr.keys().next().value);
    draw();
   }).finally(function(){ptrBusy=false;});
  }
  function refresh(){
   if(!enabled||busy||document.hidden)return Promise.resolve();
   var current=generation;busy=true;
   return sw.api('connections',{domains:domains.input.checked}).then(function(result){
    if(current!==generation||document.hidden)return;
    if(domains.input.checked)remember(result.replies);
    dnsStatus.textContent=domains.input.checked?(result.dns_message||'Estimates use recent DNS replies captured on the LAN. Open a site to generate a fresh DNS query.'):'';
    rows=result.rows||[];draw();
    lookup();
    status.textContent=result.message||(rows.length?(result.capped?'Showing up to ':'')+rows.length+' connections'+(result.node?' · '+result.node:''):'No established STRXWall TCP connections.');
   }).catch(function(error){
    if(current===generation)status.textContent=error.message||'Unable to refresh connections.';
   }).finally(function(){busy=false;});
  }
  toggle.input.addEventListener('change',function(){
   generation++;enabled=toggle.input.checked;
   if(enabled){status.textContent='Loading connections…';refresh();}
   else{rows=[];hints.clear();ptr.clear();dnsStatus.textContent='';draw();status.textContent='Live monitoring is paused.';}
  });
  domains.input.addEventListener('change',function(){
   generation++;hints.clear();dnsStatus.textContent='';draw();refresh();
  });
  reverse.input.addEventListener('change',function(){draw();lookup();});
  filter.addEventListener('input',draw);
  poll.add(refresh,5);
  return sw.layout('connections','Connections','Established LAN TCP connections redirected through STRXWall.',E('div',{class:'sw-card'},[
   E('div',{class:'sw-toolbar'},[toggle.node,domains.node,reverse.node,filter]),status,dnsStatus,
   E('div',{class:'sw-table-wrap'},E('table',{class:'sw-table'},[
    E('thead',{},E('tr',{},['Device','Destination','Domain','Protocol'].map(function(label){return E('th',{},label);}))),body
   ]))
  ]));
 },
 handleSaveApply:null,handleSave:null,handleReset:null
});
