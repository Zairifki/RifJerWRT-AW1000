'use strict';
'require view';
'require poll';
'require ui';
'require strxwall.common as sw';
return view.extend({
 load:function(){return sw.api('overview');},
 render:function(initial){
  var data=initial,group='All',search='',selected=new Set(),showAddress=false,latencies={},live=true,latencyBusy=false,cursor=0;
  var content=E('div'),groups=E('div',{class:'sw-groups'}),table=E('div');
  var searchBox=sw.input('');searchBox.classList.add('sw-search');searchBox.placeholder='Search nodes or server…';
  var address=sw.toggle(false,'Show server addresses');
  var liveControl=sw.toggle(true,'Live ping · 10s');
  function latencyText(r,key,error){return r?(r[key]!=null?(r[key]<1?'<1 ms':Math.round(r[key])+' ms'):(r.unsupported?'Unavailable':r[error]||'Timeout')):'—';}
  function pingNode(id){return sw.api('node_latency',{id:id,icmp_only:true}).then(function(r){latencies[id]=r;}).catch(function(){latencies[id]={ping_error:'Unavailable',tcp_error:'Unavailable'};});}
  function sample(){if(!live||latencyBusy||document.hidden)return Promise.resolve();var rows=data.nodes.filter(function(n){return(group==='All'||n.group===group)&&((n.name+' '+n.address+' '+n.group).toLowerCase().indexOf(search.toLowerCase())!==-1);});if(!rows.length)return Promise.resolve();latencyBusy=true;var chosen=[];for(var i=0;i<Math.min(2,rows.length);i++)chosen.push(rows[(cursor+i)%rows.length]);cursor=(cursor+chosen.length)%rows.length;return Promise.all(chosen.map(function(n){return pingNode(n.id);})).then(function(){latencyBusy=false;draw();});}
  liveControl.input.addEventListener('change',function(){live=liveControl.input.checked;if(live)sample();});
  function reload(){return sw.api('overview').then(function(v){data=v;draw();});}
  function confirmDelete(ids){sw.modal('Delete '+ids.length+' node(s)?',E('p',{},'Deleting the active node also disables STRXWall. Subscription nodes may return on refresh.'),'Delete',function(){return sw.api('node_delete',{ids:ids}).then(function(){ids.forEach(function(id){selected.delete(id);});return reload();});});}
  function draw(){
   var all=data.nodes||[],counts={All:all.length};all.forEach(function(n){counts[n.group]=(counts[n.group]||0)+1;});
   if(!counts[group])group='All';groups.replaceChildren();Object.keys(counts).forEach(function(g){groups.appendChild(E('button',{type:'button',class:'sw-group'+(group===g?' active':''),click:function(){group=g;draw();}},g+' · '+counts[g]));});
   var rows=all.filter(function(n){return(group==='All'||n.group===group)&&((n.name+' '+n.address+' '+n.group).toLowerCase().indexOf(search.toLowerCase())!==-1);});
   var checkAll=E('input',{type:'checkbox',checked:rows.length&&rows.every(function(n){return selected.has(n.id);})?true:null,change:function(ev){rows.forEach(function(n){if(ev.target.checked)selected.add(n.id);else selected.delete(n.id);});draw();}});
   var body=E('tbody',{},rows.map(function(n){
    var latency=latencies[n.id],cap=(data.capabilities||{})[n.id];
    var checkbox=E('input',{type:'checkbox',checked:selected.has(n.id)?true:null,change:function(ev){if(ev.target.checked)selected.add(n.id);else selected.delete(n.id);}});
    return E('tr',{},[E('td',{},checkbox),E('td',{},[E('div',{class:'sw-name'},n.name),E('div',{class:'sw-sub'},n.protocol.toUpperCase()+' / '+n.transport+(showAddress?' · '+n.address+':'+n.port:''))]),E('td',{'data-label':'Group'},E('span',{class:'sw-badge'},n.group)),E('td',{'data-label':'Selection'},[E('span',{class:'sw-badge'+(n.active?' active':'')},n.active?'Active':n.eligible?'Backup eligible':'Manual only')]),E('td',{'data-label':'IP support',title:cap?'Tested from this router at '+new Date(cap.checked_at*1000).toLocaleString():'Run Detect IP or enable active-node detection'},E('span',{class:'sw-badge'+(cap&&cap.label==='Dual-stack'?' active':'')},cap?cap.label:'Not detected')),E('td',{'data-label':'Ping',title:'ICMP echo to the node server'},E('span',{class:latency&&latency.ping_ms!=null?'sw-good':'sw-muted'},latencyText(latency,'ping_ms','ping_error'))),E('td',{},E('div',{class:'sw-actions'},[
     sw.button('Detect IP',function(){return sw.api('node_detect',{id:n.id}).then(function(){sw.notify('IPv4/IPv6 tunnel detection requested. Check the IP support column and Logs in about a minute.');});},'ghost'),
     sw.button('Ping',function(){return pingNode(n.id).then(draw);},'ghost'),
     sw.button(n.active?'Selected':'Use',function(){return sw.api('node_use',{id:n.id}).then(reload);},n.active?'ghost':'primary'),
     sw.button('Copy',function(){return sw.api('node_copy',{id:n.id}).then(reload);},'ghost'),
     sw.button('Edit',function(){return sw.editNode(n.id,reload);},'ghost'),
     sw.button('Delete',function(){confirmDelete([n.id]);},'danger')
    ]))]);
   }));
   table.replaceChildren();if(!rows.length){table.appendChild(E('div',{class:'sw-empty'},[E('strong',{},all.length?'No matching nodes':'Your node list is ready'),E('p',{},all.length?'Try another group or search.':'Create a node or paste a share link to get started.'),sw.button('Add via link',function(){sw.importModal(reload);},'primary')]));return;}
   table.appendChild(E('div',{class:'sw-table-wrap sw-node-table'},E('table',{class:'sw-table'},[E('thead',{},E('tr',{},[E('th',{},checkAll),E('th',{},'Node'),E('th',{},'Group'),E('th',{},'Selection'),E('th',{},'IP support'),E('th',{},'Ping'),E('th',{},'Actions')])),body])));
  }
  searchBox.addEventListener('input',function(){search=searchBox.value;draw();});address.input.addEventListener('change',function(){showAddress=address.input.checked;draw();});
  content.appendChild(E('div',{class:'sw-card'},[E('div',{class:'sw-sub',style:'margin-bottom:16px'},'Ping measures ICMP latency from the router to your node server.'),E('div',{class:'sw-toolbar'},[groups,searchBox]),E('div',{class:'sw-toolbar'},[E('div',{class:'sw-actions'},[address.node,liveControl.node]),sw.button('Delete selected',function(){var ids=Array.from(selected);if(!ids.length){sw.notify('Select one or more nodes.');return;}confirmDelete(ids);},'danger')]),table]));
  draw();poll.add(reload,5);poll.add(sample,10);sample();
  return sw.layout('nodes','My nodes','Live ICMP latency, node groups and connection controls. Up to two visible nodes are sampled every 10 seconds.',content,[sw.button('Add via link',function(){sw.importModal(reload);},'primary'),sw.button('Create node',function(){return sw.editNode(null,reload);}),sw.button('Refresh',reload,'ghost')]);
 },handleSaveApply:null,handleSave:null,handleReset:null
});
