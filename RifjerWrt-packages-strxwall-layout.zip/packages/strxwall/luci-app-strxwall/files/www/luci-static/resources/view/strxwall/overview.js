'use strict';
'require view';
'require poll';
'require strxwall.common as sw';
return view.extend({
 load:function(){return sw.api('overview');},
 render:function(initial){
  var pingData=null,pingBusy=false,pingLive=true,poolDirty=false,websiteBusy=false,generation=0;
  var udpResult=null,udpBusy=false,udpAttempt=0,dnsResult=null,dnsBusy=false,diagnosticBusy=false;
  var healthPanel=E('div',{class:'sw-health-row'}),recoveryPanel=E('div',{class:'sw-recovery-bar'});
  var switchBusy=false,reloadTask=null;
  var proxyCheck=null,proxyBusy=false,serviceBusy=false,adguardBusy=false;
  var serviceControls=E('div',{class:'sw-actions'}),proxyPanel=E('div');
  var identityBusy=false,identityLastAttempt=0,identityError=false;
  var proxyCountry=null,countryBusy=false,countryLastAttempt=0,countryEpoch=0;
  var sites=[['google','G','Google'],['github','GH','GitHub'],['youtube','YT','YouTube'],['cloudflare','CF','Cloudflare']];
  var data=initial,identity=null,reveal=false,dirty=false,checks={},route='tunnel';
  var globalPanel=E('div',{class:'sw-status-strip'});
  var poolSummary=E('summary'),poolDisclosure=E('details',{class:'sw-pool-disclosure',open:true},[poolSummary]);
  var runtimeDisclosure=E('details',{class:'sw-runtime'});
  var livePanel=E('div',{class:'sw-card sw-live-panel'}),poolPanel=E('div',{class:'sw-card'});
  var identityPanel=E('div',{class:'sw-monitor-identity'}),quickPanel=E('div',{class:'sw-monitor-controls'}),notices=E('div'),checkPanel=E('div',{class:'sw-website-panel'}),corePanel=E('div',{class:'sw-runtime-content'}),checkSummary=E('strong',{class:'sw-check-summary'});
  var routeChoice=sw.select([['tunnel','Through STRX tunnel'],['direct','Router direct']],route);
  routeChoice.addEventListener('change',function(){route=routeChoice.value;identity=null;reveal=false;checks={};generation++;identityLastAttempt=0;identityError=false;drawIdentity();drawPing();sampleWebsites();sampleIdentity();});
  function ready(v){return v.status.ready==null?v.status.running:v.status.ready;}
  function eventKey(v){var e=(v.status.failover||{}).last_event||{};return [e.checked_at||'',e.kind||'',e.to||''].join('|');}
  function refreshConnection(){return Promise.allSettled([samplePing(true),sampleWebsites(true),sampleCountry(true),sampleIdentity(true),sampleProxy(true),sampleUDP(true),sampleDNS(true)]);}
  function reload(){
   if(document.hidden)return Promise.resolve();if(reloadTask)return reloadTask;
   reloadTask=sw.api('overview').then(function(v){
    var changed=data.global.node!==v.global.node||data.status.running!==v.status.running||ready(data)!==ready(v)||data.status.active_node!==v.status.active_node||eventKey(data)!==eventKey(v);
    var switched=changed&&ready(v);
    if(changed){dnsResult=null;proxyCheck=null;pingData=null;pingHistory=[];checks={};identity=null;udpResult=null;udpAttempt=0;proxyCountry=null;countryEpoch++;countryLastAttempt=0;generation++;identityLastAttempt=0;identityError=false;reveal=false;}
    data=v;drawService();drawIdentity();drawStatus();drawPing();drawChecks();if(!dirty)drawQuick();if(!poolDirty)drawPool();drawRecovery();drawHealth();
    if(switched)refreshConnection();else sampleIdentity();
   }).finally(function(){reloadTask=null;});return reloadTask;
  }
  function sampleSwitch(){
   if(document.hidden||switchBusy||serviceBusy)return Promise.resolve();switchBusy=true;
   return sw.api('switch_status').then(function(r){
    var e=(r.failover||{}).last_event||{},key=[e.checked_at||'',e.kind||'',e.to||''].join('|');
    if(r.enabled!==data.global.enabled||r.node!==data.global.node||r.active_node!==data.status.active_node||r.ready!==ready(data)||key!==eventKey(data))return reload();
    data.status.failover=r.failover||{};data.status.switch_pending=r.switch_pending;data.status.switch_error=r.switch_error;data.global.auto_switch=r.auto_switch;data.global.auto_return=r.auto_return;data.global.return_target=r.return_target;data.global.return_active=r.return_active;drawRecovery();drawStatus();
   }).catch(function(){}).finally(function(){switchBusy=false;});
  }
  function drawRecovery(){
   var f=data.status.failover||{},target=f.return_node||(data.global.return_active===data.global.node?data.global.return_target:null);
   if(target&&!data.nodes.some(function(n){return n.id===target;}))target=null;
   var active=data.nodes.find(function(n){return n.id===data.global.node;}),previous=data.nodes.find(function(n){return n.id===target;});
   var title=!ready(data)?(data.global.enabled==='1'?'Switching to ':'Service stopped · ')+(active?active.name:'selected node'):'Using '+(active?active.name:'no node');
   var message=data.global.auto_switch!=='1'?'Automatic switching is off':target?(data.global.auto_return==='0'?'Automatic return paused':((f.recovery_passes||0)>=3?'Recovered · waiting for cooldown':'Waiting for '+(previous?previous.name:target)+' · Recovery '+(f.recovery_passes||0)+'/3')):'Automatic switching ready';
   var last=f.last_event;
   recoveryPanel.replaceChildren(E('strong',{},title),E('span',{},message));
   if(data.status.switch_pending&&active)recoveryPanel.appendChild(E('small',{},'Verifying '+active.name+'…'));
   if(data.status.switch_error)recoveryPanel.appendChild(E('small',{class:'sw-warn'},data.status.switch_error));
   if(last&&!data.status.switch_pending&&!data.status.switch_error)recoveryPanel.appendChild(E('small',{},(last.kind==='return'?'Returned':'Switched')+' '+new Date(last.checked_at*1000).toLocaleTimeString()));
   recoveryPanel.setAttribute('role','status');
  }
  function textTime(value){return value!=null?Math.round(value)+' ms':'—';}
  function detail(label,value){return E('div',{},[E('div',{class:'sw-label'},label),E('strong',{},value||'—')]);}
  function drawPool(){
   poolPanel.replaceChildren();var saved=data.global.failover_order||[];if(!Array.isArray(saved))saved=String(saved).trim().split(/\s+/);var order=saved.filter(function(id,i){return saved.indexOf(id)===i&&data.nodes.some(function(n){return n.id===id;});});data.nodes.forEach(function(n){if(order.indexOf(n.id)===-1)order.push(n.id);});var selected=new Set(data.nodes.filter(function(n){return n.eligible;}).map(function(n){return n.id;}));
   var enabled=sw.toggle(data.global.auto_switch==='1','Enable automatic switching'),returnControl=sw.toggle(data.global.auto_return!=='0','Return to previous node');returnControl.input.addEventListener('change',function(){poolDirty=true;});
   var list=E('div',{class:'sw-backup-list'}),summary=E('div',{class:'sw-pool-summary'}),search=sw.input('');search.placeholder='Find a backup node…';search.classList.add('sw-search');
   function count(){var backups=Array.from(selected).filter(function(id){return id!==data.global.node;}).length;summary.replaceChildren(E('span',{},selected.size+' selected · '+backups+' available as backups for the current node'));}
   function drawList(){list.replaceChildren();var term=search.value.toLowerCase(),ordered=order.map(function(id){return data.nodes.find(function(n){return n.id===id;});}),fallback=order.filter(function(id){return selected.has(id)&&id!==data.global.node;});ordered.filter(function(n){return(n.name+' '+n.group).toLowerCase().indexOf(term)!==-1;}).forEach(function(n){
    var nodeToggle=sw.toggle(selected.has(n.id),'Include '+n.name+' in backup pool'),box=nodeToggle.input;box.addEventListener('change',function(){poolDirty=true;if(box.checked)selected.add(n.id);else selected.delete(n.id);drawList();count();});
    var rank=n.id===data.global.node?'Active':selected.has(n.id)?'#'+(fallback.indexOf(n.id)+1):'—';
    function move(delta){var index=order.indexOf(n.id),next=index+delta;if(next<0||next>=order.length)return;order.splice(index,1);order.splice(next,0,n.id);poolDirty=true;drawList();}
    list.appendChild(E('div',{class:'sw-backup-node'},[E('span',{class:'sw-sequence-rank'},rank),nodeToggle.node,E('div',{class:'sw-backup-description'},[E('strong',{},n.name),E('small',{},n.protocol.toUpperCase()+' / '+n.transport+' · '+n.group+(n.id===data.global.node?' · Current node':''))]),E('div',{class:'sw-order-buttons'},[
     E('button',{type:'button',class:'sw-btn ghost',title:'Move '+n.name+' up','aria-label':'Move '+n.name+' up',disabled:order.indexOf(n.id)===0?true:null,click:function(){move(-1);}},'↑'),
     E('button',{type:'button',class:'sw-btn ghost',title:'Move '+n.name+' down','aria-label':'Move '+n.name+' down',disabled:order.indexOf(n.id)===order.length-1?true:null,click:function(){move(1);}},'↓')
    ])]));
   });if(!list.children.length)list.appendChild(E('div',{class:'sw-empty'},data.nodes.length?'No matching nodes.':'Add at least two nodes to use automatic switching.'));}
   enabled.input.addEventListener('change',function(){poolDirty=true;});search.addEventListener('input',drawList);
   poolPanel.appendChild(E('div',{class:'sw-toolbar'},[E('div',{},[E('div',{class:'sw-kicker'},'YOUR BACKUP POOL'),E('h3',{},'Choose nodes for auto switch'),E('div',{class:'sw-sub'},'Selected nodes are tried in numbered order. Use ↑ / ↓ to change the sequence.')]),enabled.node]));
   poolPanel.appendChild(E('div',{class:'sw-toolbar'},[returnControl.node,E('span',{class:'sw-sub'},'Return after 3 successful checks and cooldown. Manual node changes cancel the pending return.')]));
   poolPanel.appendChild(E('div',{class:'sw-toolbar'},[search,E('div',{class:'sw-actions'},[sw.button('Select all',function(){poolDirty=true;data.nodes.forEach(function(n){selected.add(n.id);});drawList();count();},'ghost'),sw.button('Clear selection',function(){poolDirty=true;selected.clear();drawList();count();},'ghost')])]));
   poolPanel.appendChild(summary);poolPanel.appendChild(list);
   poolPanel.appendChild(E('div',{class:'sw-toolbar'},[E('div',{class:'sw-sub'},'Include the current node too if you want it eligible again after a switch. After you save, new imports stay outside your pool until selected.'),sw.button('Save auto switch',function(){return sw.api('failover_settings',{enabled:enabled.input.checked?'1':'0',return_enabled:returnControl.input.checked?'1':'0',nodes:order.filter(function(id){return selected.has(id);}),order:order}).then(function(){poolDirty=false;sw.notify('Auto-switch pool saved. It will be used on the next health check.');return reload();});},'primary')]));
   drawList();count();poolSummary.replaceChildren(E('span',{},'Auto switch '+(data.global.auto_switch==='1'?'ON':'OFF')),E('span',{class:'sw-sub'},data.nodes.filter(function(n){return n.eligible&&n.id!==data.global.node;}).length+' backup nodes'),E('span',{class:'sw-sub'},(data.status.failover||{}).return_node?(data.global.auto_return==='0'?'Return paused':'Recovery '+(data.status.failover.recovery_passes||0)+'/3'):(data.status.failover||{}).last_event?'Last switch '+new Date(data.status.failover.last_event.checked_at*1000).toLocaleTimeString():'Manage backups ⌄'));
  }
  function changeNode(){
   var node=sw.select(data.nodes.map(function(n){return[n.id,n.name];}),data.global.node||'');
   var status=E('div',{role:'status','aria-live':'polite'});
   sw.modal('Change active node',E('div',{},[sw.field('Node',node),status]),'Apply connection',function(){
    status.className='sw-muted';status.textContent='Switching node…';
    node.disabled=true;
    return sw.api('node_use',{id:node.value}).then(function(){
     dirty=false;
     reload().catch(function(){});
    },function(e){
     status.className='sw-warn';status.textContent=e.message;
     throw e;
    }).finally(function(){node.disabled=false;});
   });
  }
  var pingHistory=[];
  function sparkline(){
   var ns='http://www.w3.org/2000/svg';
   var svg=document.createElementNS(ns,'svg');
   svg.setAttribute('class','sw-ping-spark');
   svg.setAttribute('viewBox','0 0 120 26');
   svg.setAttribute('aria-hidden','true');
   var pts=pingHistory.length>=2?pingHistory:(pingHistory.length===1?[pingHistory[0],pingHistory[0]]:[20,20]);
   var min=Math.min.apply(null,pts),max=Math.max.apply(null,pts),span=Math.max(5,max-min);
   var coords=pts.map(function(v,i){
    var x=(pts.length===1?60:(i/(pts.length-1))*116+2).toFixed(1);
    var y=(22-((v-min)/span)*16).toFixed(1);
    return x+','+y;
   }).join(' ');
   var poly=document.createElementNS(ns,'polyline');
   poly.setAttribute('fill','none');
   poly.setAttribute('stroke',pingHistory.length?'#00e5ff':'#264659');
   poly.setAttribute('stroke-width','2');
   poly.setAttribute('stroke-linecap','round');
   poly.setAttribute('stroke-linejoin','round');
   poly.setAttribute('points',coords);
   svg.appendChild(poly);
   return svg;
  }
  function drawPing(){
   var active=data.nodes.find(function(n){return n.id===data.global.node;}),r=pingData&&pingData.id===data.global.node?pingData:null;
   var ping=!active?'—':!r?'Waiting…':r.ping_ms!=null?textTime(r.ping_ms):r.ping_error||'Unavailable';
   livePanel.replaceChildren(E('div',{class:'sw-kicker sw-monitor-title'},'LIVE CONNECTION MONITOR'),globalPanel,quickPanel,recoveryPanel,
    E('div',{class:'sw-compact-grid'},[
     E('div',{class:'sw-active-card'},[
      E('div',{class:'sw-active-heading'},[E('div',{},[countryBadge(),E('h3',{},active?active.name:'Choose a node')]),sw.button('Change node',changeNode,'primary sw-change-node-btn')]),
      E('div',{class:'sw-node-meta'},[E('span',{},active?active.protocol.toUpperCase()+' / '+active.transport:'Add your own node'),sparkline(),E('span',{class:'sw-latency-chip',title:'ICMP latency from router to node'},ping)]),identityPanel,healthPanel
     ]),
     E('div',{class:'sw-compact-web'},[E('div',{class:'sw-monitor-section-head'},[E('h3',{},'Website Connectivity'),E('div',{class:'sw-actions'},[checkSummary,sw.button('Refresh now',function(){return Promise.all([samplePing(true),sampleWebsites(true),sampleCountry(true),sampleIdentity(true),sampleProxy(true),sampleUDP(true),sampleDNS(true)]);},'ghost')])]),checkPanel])
    ])
   );
   drawChecks();drawRecovery();drawHealth();
  }
  function udpLabel(){
   if(data.global.udp_mode==='block')return 'UDP blocked';
   if(data.global.udp_mode!=='same')return 'UDP direct';
   var r=udpResult;
   if(!data.status.running||!data.status.firewall)return 'UDP proxy inactive';
   return r&&r.node===data.global.node&&Date.now()-r.received_at<120000?(r.error?'UDP check unavailable':r.ok?'UDP tunnel verified':'UDP tunnel check failed'):'UDP same as TCP · unverified';
  }
  function sampleUDP(force){
   if((!pingLive&&!force)||udpBusy||document.hidden||data.global.udp_mode!=='same'||!ready(data))return Promise.resolve();
   if(!force&&udpAttempt&&Date.now()-udpAttempt<60000)return Promise.resolve();
   var epoch=generation,id=data.global.node;udpBusy=true;udpAttempt=Date.now();
   return sw.api('udp_check').then(function(v){if(epoch===generation&&id===data.global.node)udpResult=Object.assign({},v,{received_at:Date.now()});}).catch(function(){if(epoch===generation)udpResult={node:id,error:true,received_at:Date.now()};}).then(function(){udpBusy=false;drawStatus();drawPing();if(epoch!==generation&&ready(data))return sampleUDP(true);});
  }
  function drawGlobal(){
   var st=data.status,active=data.nodes.find(function(n){return n.id===data.global.node;});
   globalPanel.replaceChildren(proxyPanel,E('span',{class:'sw-core-pill '+(st.running?'sw-good':'sw-warn')},st.running?'Core running':'Core stopped'),E('span',{class:'sw-strip-node'},active?active.name:'No active node'));
   drawProxy();
  }
  function drawProxy(){
   var r=proxyCheck,state=r?r.state:proxyBusy||(!ready(data)&&data.global.enabled==='1')?'checking':!data.status.running?'disconnected':'unavailable';
   if(r&&Date.now()-r.received_at>150000&&!proxyBusy)state='unavailable';
   var label=state==='connected'?'Proxy connected':state==='disconnected'?'Proxy disconnected':state==='checking'?'Checking':'Check unavailable';
   proxyPanel.replaceChildren(E('div',{class:'sw-proxy-state sw-proxy-'+state,role:'status','aria-live':'polite'},[E('span',{'aria-hidden':'true'},state==='connected'?'●':state==='disconnected'?'⊘':'◌'),E('strong',{},label)]),
    E('div',{class:'sw-sub'},(r?'Last check '+new Date(r.checked_at*1000).toLocaleTimeString():'No completed check')+(!pingLive?' · Paused':'')+(r&&r.reason?' · '+r.reason:'')));
  }
  function sampleProxy(force){
   if((!pingLive&&!force)||proxyBusy||document.hidden||!ready(data))return Promise.resolve();
   var epoch=generation,id=data.global.node;proxyBusy=true;drawProxy();
   return sw.api('proxy_check').then(function(r){if(epoch===generation&&id===data.global.node)proxyCheck=Object.assign({},r,{received_at:Date.now()});}).catch(function(e){if(epoch===generation)proxyCheck={state:'unavailable',reason:e.message,checked_at:Date.now()/1000,received_at:Date.now()};}).then(function(){proxyBusy=false;drawProxy();drawHealth();if(epoch!==generation&&ready(data))return sampleProxy(true);});
  }
  function drawHealth(){
   var fresh=dnsResult&&Date.now()-dnsResult.received_at<150000,d=fresh?dnsResult:null;
   function chip(label,value,state){return E('div',{class:'sw-health-chip '+(state==='ok'?'sw-good':state==='failed'?'sw-bad':state==='neutral'?'sw-muted':'sw-warn')},[E('span',{class:'sw-label'},label),E('strong',{},value)]);}
   var tcp=proxyCheck&&Date.now()-proxyCheck.received_at<150000?proxyCheck.state:'unavailable';
   var records=d&&d.records||{};
   function answer(v){return v==='ok'?'✓':v==='failed'?'failed':v==='no_records'?'no records':v==='misconfigured'?'misconfigured':'—';}
   healthPanel.replaceChildren(chip('TCP tunnel',tcp==='connected'?'Connected':tcp==='disconnected'?'Failed':proxyBusy?'Checking':'Unavailable',tcp==='connected'?'ok':tcp==='disconnected'?'failed':'unknown'),chip('UDP',udpLabel().replace(/^UDP /,''),data.global.udp_mode!=='same'?'neutral':(udpResult&&data.status.running&&data.status.firewall&&Date.now()-udpResult.received_at<120000)?(udpResult.error?'unknown':udpResult.ok?'ok':'failed'):'unknown'),chip('DNS',d?'A '+answer(records.A)+' · AAAA '+answer(records.AAAA):dnsBusy?'Checking':'Unavailable',d?(d.state==='healthy'?'ok':d.state==='failed'?'failed':'unknown'):'unknown'));
   healthPanel.appendChild(E('small',{class:'sw-dns-health-note'},d?(d.reason+' · '+new Date(d.checked_at*1000).toLocaleTimeString()):'Checks the router DNS path; AAAA answers do not prove IPv6 internet access.'));
  }
  function sampleDNS(force){
   if(document.hidden||dnsBusy||!ready(data))return Promise.resolve();
   var epoch=generation;dnsBusy=true;drawHealth();
   return sw.api('dns_health').then(function(r){if(epoch===generation)dnsResult=Object.assign({},r,{received_at:Date.now()});}).catch(function(e){if(epoch===generation)dnsResult={state:'unavailable',reason:e.message,checked_at:Date.now()/1000,received_at:Date.now()};}).then(function(){dnsBusy=false;drawHealth();if(epoch!==generation&&ready(data))return sampleDNS(true);});
  }
  function diagnostics(){
   if(diagnosticBusy)return Promise.resolve();diagnosticBusy=true;
   return Promise.all([sampleProxy(true),sampleDNS(true),sampleUDP(true)]).then(function(){return sw.api('diagnostics');}).then(function(v){
    var d=v.dns||{},records=d.records||{},r=proxyCheck;
    var rows=[detail('Proxy tunnel',r?r.state:'Unavailable'),detail('Proxy check reason',r&&r.reason||(r&&r.state==='connected'?'HTTPS request through SOCKS succeeded':'No completed check')),detail('TCP',r&&r.state==='connected'?'Connected':'Not verified'),detail('UDP',udpLabel()),detail('DNS A',records.A||'Unavailable'),detail('DNS AAAA',records.AAAA||'Unavailable'),detail('DNS path',d.reason||'Unavailable'),detail('DNS provider',d.provider||'Unavailable'),detail('Core process',v.running?'Running':'Stopped'),detail('LAN firewall',v.firewall?'Installed':'Inactive'),detail('Startup error',v.error||'None'),detail('Failover',data.status.maintenance||'No checks yet')];
    sw.modal('Connection diagnostics',E('div',{},[E('div',{class:'sw-fields'},rows),E('p',{class:'sw-muted'},'A/AAAA DNS resolution, TCP and UDP are independent checks. Cached DNS answers can pass while an upstream is unavailable. This does not test every LAN application.')]),'Done',function(){return Promise.resolve();});
   }).catch(function(e){sw.notify(e.message,'danger');}).finally(function(){diagnosticBusy=false;});
  }
  function drawService(){
   serviceControls.replaceChildren();
   ['start','stop','restart'].forEach(function(action){
    var label=action.charAt(0).toUpperCase()+action.slice(1)+' service';
    var b=E('button',{type:'button',class:'sw-btn '+(action==='restart'?'sw-restart-icon':action==='stop'?'danger':'ghost'),title:label,'aria-label':label,disabled:serviceBusy||adguardBusy||(action==='start'?(data.status.service_running==null?data.status.running:data.status.service_running):!(data.status.service_running==null?data.status.running:data.status.service_running))?true:null,click:function(){
     if(serviceBusy||adguardBusy)return;serviceBusy=true;generation++;drawQuick();drawService();proxyCheck=null;drawProxy();
     sw.api('service',{command:action}).then(function(result){sw.notify(result.already_started?(result.running?'Core is already running.':'STRXWall is already starting.'):label+' completed.');dirty=false;return reload();}).then(function(){return sampleProxy(true);}).catch(function(e){sw.notify(e.message,'danger');}).finally(function(){serviceBusy=false;drawQuick();drawService();reload().catch(function(){});});
    }},label);serviceControls.appendChild(b);
   });
   if(adguardBusy)serviceControls.appendChild(E('span',{role:'status',class:'sw-warn'},'Applying DNS…'));
   if(serviceBusy)serviceControls.appendChild(E('span',{role:'status',class:'sw-warn'},'Service action in progress…'));
   var resources=data.status.resources||{};
   if(resources.mem_available_kib!=null)serviceControls.appendChild(E('span',{class:'sw-muted'},'Available RAM: '+Math.round(resources.mem_available_kib/1024)+' MiB'));
   if(resources.passwall_xray)serviceControls.appendChild(E('span',{class:'sw-warn'},'PassWall Xray detected'));
  }
  function countryBadge(){
   var code=proxyCountry&&String(proxyCountry.country_code||'').toUpperCase();
   var name=proxyCountry&&proxyCountry.country||'Unknown country';
   var available=!!(proxyCountry&&/^[A-Z]{2}$/.test(code));
   var icon=available&&['MY','SG','ID'].indexOf(code)!==-1?
    E('img',{class:'sw-country-flag',src:'/luci-static/resources/strxwall/flags/'+code.toLowerCase()+'.svg',alt:name+' flag'}):
    E('span',{class:'sw-country-code'},available?code:'—');
   return E('span',{class:'sw-country-chip',title:'Approximate proxy exit country, detected through the STRX tunnel. Refreshed every minute.'},[
    icon,E('span',{},!data.status.running?'Tunnel stopped':available?name:(countryBusy||identityBusy)?'Detecting country…':name)
   ]);
  }
  function sampleCountry(force){
   if(route==='tunnel')return sampleIdentity(force);
   if((!pingLive&&!force)||countryBusy||document.hidden||!ready(data)||!data.global.node)return Promise.resolve();
   if(!force&&countryLastAttempt&&Date.now()-countryLastAttempt<(proxyCountry?60000:60000))return Promise.resolve();
   var epoch=countryEpoch,id=data.global.node;countryBusy=true;countryLastAttempt=Date.now();drawPing();
   return sw.api('proxy_country').then(function(v){
    if(epoch===countryEpoch&&id===data.global.node&&data.status.running)proxyCountry=v;
   }).catch(function(){if(epoch===countryEpoch)proxyCountry=null;}).then(function(){countryBusy=false;drawPing();if(epoch!==countryEpoch&&ready(data))return sampleCountry(true);});
  }
  function samplePing(force){
   if((!pingLive&&!force)||pingBusy||document.hidden||!data.global.node)return Promise.resolve();
   var id=data.global.node;pingBusy=true;
   return sw.api('node_latency',{id:id,icmp_only:true}).then(function(r){if(data.global.node===id){pingData=r;if(r&&r.ping_ms!=null){pingHistory.push(Number(r.ping_ms));if(pingHistory.length>14)pingHistory.shift();}}}).catch(function(){if(data.global.node===id)pingData={id:id,ping_error:'Unavailable',tcp_error:'Unavailable'};}).then(function(){pingBusy=false;drawPing();if(id!==data.global.node&&ready(data))return samplePing(true);});
  }
  function sampleIdentity(force){
   if((!pingLive&&!force)||identityBusy||document.hidden||(route==='tunnel'&&!ready(data)))return Promise.resolve();
   if(!force&&identityLastAttempt&&Date.now()-identityLastAttempt<(identity?60000:60000))return Promise.resolve();
   var requestRoute=route,epoch=generation;identityBusy=true;identityLastAttempt=Date.now();identityError=false;drawIdentity();
   return sw.api('connection_info',{route:requestRoute}).then(function(result){
    if(route!==requestRoute||epoch!==generation)return;
    if(!identity||identity.ip!==result.ip)reveal=false;
    identity=result;
    if(requestRoute==='tunnel'){proxyCountry={country:result.country,country_code:result.country_code,checked_at:result.checked_at};countryLastAttempt=Date.now();}
   }).catch(function(){if(route===requestRoute&&epoch===generation){identity=null;identityError=true;reveal=false;if(requestRoute==='tunnel')proxyCountry=null;}}).then(function(){
    identityBusy=false;drawIdentity();drawPing();
    if(epoch!==generation){identityLastAttempt=0;return sampleIdentity();}
   });
  }
  function drawIdentity(){
   identityPanel.replaceChildren();var geo=identity;
   identityPanel.appendChild(E('div',{class:'sw-monitor-section-head'},[E('span',{class:'sw-label'},route==='tunnel'?'Proxy exit identity':'Router direct identity'),E('span',{class:'sw-badge'},identityBusy?'Updating…':geo?geo.country_code||'IP':identityError?'Retrying automatically':'IP hidden')]));
   identityPanel.appendChild(E('div',{class:'sw-public-ip'},geo?(reveal?geo.ip:'•••.•••.•••.•••'):identityError?'Identity unavailable':route==='tunnel'&&!data.status.running?'Tunnel stopped':'Detecting exit IP…'));
   var revealButton=sw.button(geo&&reveal?'Hide IP':'Show IP',function(){if(!identity)return;reveal=!reveal;drawIdentity();},'ghost');revealButton.disabled=!geo;
   identityPanel.appendChild(E('div',{class:'sw-actions'},[revealButton,E('span',{class:'sw-sub'},identityBusy?'Updating identity…':identityError?'Retry in 60s':!pingLive?'Updates paused':'Auto update · every 1 min')]));
   identityPanel.appendChild(E('div',{class:'sw-identity-facts'},[
    detail('Location',geo?[geo.city,geo.country].filter(Boolean).join(', '):'Not checked'),
    detail('Network / ISP',geo?geo.isp:'Not checked'),

   ]));
   identityPanel.appendChild(E('div',{class:'sw-sub'},'Approximate exit location · IP stays hidden until revealed.'));
  }
  function drawQuick(){
   quickPanel.replaceChildren();var g=data.global,policy=data.status.dns_policy||{};
   var enabled=sw.toggle(g.enabled==='1','Enable STRXWall'),adguard=sw.toggle(!!policy.enabled,'AdBlock');
   var modes=[['ipv4','DNS · IPv4'],['ipv6','DNS · IPv6'],['dual','DNS · IPv4 + IPv6']];if(!g.dns_ip_mode)modes.unshift(['legacy','DNS · existing settings']);var mode=sw.select(modes,g.dns_ip_mode||'legacy');
   mode.setAttribute('aria-label','DNS upstream IP mode');
   enabled.input.disabled=serviceBusy||adguardBusy;adguard.input.disabled=serviceBusy||adguardBusy;mode.disabled=serviceBusy||adguardBusy;
   enabled.input.addEventListener('change',function(){if(serviceBusy||adguardBusy)return;serviceBusy=true;drawQuick();drawService();sw.api('service',{command:enabled.input.checked?'start':'stop'}).then(reload).catch(function(e){sw.notify(e.message,'danger');}).finally(function(){serviceBusy=false;reload();});});
   function dnsAction(action,payload){
    if(adguardBusy||serviceBusy)return;adguardBusy=true;drawQuick();drawService();
    sw.api(action,payload).then(function(){if(data.status.running)return sw.api('service',{command:'restart'});}).then(reload).then(function(){dnsResult=null;return sampleDNS(true);}).then(function(){sw.notify('DNS settings applied.');}).catch(function(e){sw.notify(e.message,'danger');}).finally(function(){adguardBusy=false;reload();});
   }
   adguard.input.addEventListener('change',function(){dnsAction('adguard',{enabled:adguard.input.checked?'1':'0'});});
   mode.addEventListener('change',function(){if(mode.value==='legacy')return;dnsAction('dns_mode',{mode:mode.value});});
   quickPanel.appendChild(E('div',{class:'sw-control-toggles'},[enabled.node,adguard.node,mode]));
   quickPanel.appendChild(E('span',{class:'sw-dns-caption'},'AdBlock '+(policy.enabled?'ON':'OFF')+' · '+(policy.label||'Router DNS')+' · '+(g.lan_dns==='1'&&data.status.running?'LAN DNS active':'LAN DNS inactive')));
   quickPanel.appendChild(serviceControls);
  }
  function drawStatus(){
   var st=data.status,g=data.global;
   notices.replaceChildren();if(st.error)notices.appendChild(E('div',{class:'sw-note sw-error'},st.error));
   var resolver=({cloudflare6:'Cloudflare IPv6',google6:'Google IPv6',quad96:'Quad9 IPv6',adguard:'AdGuard IPv4',adguard6:'AdGuard IPv6',system:'Router system',cloudflare_doh:'Cloudflare DoH',cloudflare:'Cloudflare',google:'Google',quad9:'Quad9',custom:'Custom DNS'})[g.dns_provider||'system'];
   corePanel.replaceChildren(detail('Core',st.version),detail('Node-server DNS',st.dns_policy?(st.dns_policy.node_label+' · '+st.dns_policy.mode):resolver),detail('LAN interception',st.firewall?'Installed':'Inactive'),detail('Maintenance',st.maintenance),detail('UDP',udpLabel()),detail('LAN DNS',st.lan_dns),detail('Routing',g.mode||'local'),detail('Automatic return',(st.failover||{}).return_node?(g.auto_return==='0'?'Paused':'Waiting for recovery')+' · '+((data.nodes.find(function(n){return n.id===st.failover.return_node;})||{}).name||st.failover.return_node)+' · '+(st.failover.recovery_passes||0)+'/3':g.auto_return==='0'?'Off':'Enabled · no return pending'),detail('Auto-switch failures',String((st.failover||{}).failures||0)),detail('Last auto switch',(st.failover||{}).last_event?((st.failover.last_event.name||st.failover.last_event.to)+' · '+new Date(st.failover.last_event.checked_at*1000).toLocaleTimeString()+' · '+st.failover.last_event.reason):'No switch recorded'));
   runtimeDisclosure.replaceChildren(E('summary',{},'Runtime details'),corePanel,E('div',{class:'sw-diagnostic-route'},[E('span',{},'Diagnostic route'),routeChoice]));
  }
  function checkOne(target,requestRoute,epoch){
   if(document.hidden||epoch!==generation||route!==requestRoute)return Promise.resolve();
   var previous=checks[target]||{};checks[target]=Object.assign({},previous,{pending:true});drawChecks();
   return sw.api('network_check',{route:requestRoute,target:target}).then(function(v){
    if(route===requestRoute&&epoch===generation)checks[target]=Object.assign({},v,{received_at:Date.now()});
   }).catch(function(e){if(route===requestRoute&&epoch===generation)checks[target]={ok:false,error:e.message,received_at:Date.now()};}).then(drawChecks);
  }
  function sampleWebsites(force){
   if((!pingLive&&!force)||websiteBusy||document.hidden||(route==='tunnel'&&!ready(data)))return Promise.resolve();
   websiteBusy=true;var requestRoute=route,epoch=generation;
   // Two requests maximum; a slow round is skipped by subsequent poll ticks.
   return Promise.all(sites.slice(0,2).map(function(v){return checkOne(v[0],requestRoute,epoch);})).then(function(){
    if(!pingLive&&!force)return;
    return Promise.all(sites.slice(2).map(function(v){return checkOne(v[0],requestRoute,epoch);}));
   }).then(function(){websiteBusy=false;drawChecks();if(epoch!==generation&&ready(data))return sampleWebsites(true);},function(){websiteBusy=false;drawChecks();});
  }
  function drawChecks(){
   checkPanel.replaceChildren();
   var recent=sites.map(function(v){return checks[v[0]];}).filter(function(r){return r&&r.received_at&&Date.now()-r.received_at<150000;});
   var passed=recent.filter(function(r){return r.ok;}).length;
   checkSummary.replaceChildren(E('span',{},recent.length?passed+'/4 passed':'Waiting…'));
   checkSummary.className='sw-check-summary '+(recent.length===4&&passed===4?'sw-good':recent.length?'sw-warn':'');
   drawGlobal();
   checkPanel.appendChild(E('div',{class:'sw-sites'},sites.map(function(v){
    var r=checks[v[0]],fresh=r&&r.received_at&&Date.now()-r.received_at<150000;
    var success=!!(r&&r.ok&&fresh&&pingLive&&!document.hidden),label='Waiting…',cls='';
    if(r){
     if(r.error){label='Unavailable';cls='sw-warn';}
     else if(r.received_at){label=r.ok?'Reachable · '+textTime(r.ms):r.http_code?'HTTP '+r.http_code:(r.reason||'No response');cls=r.ok?'sw-good':'sw-warn';}
     else if(r.pending)label='Checking…';
     if(!fresh&&r.received_at){label='Stale · refresh needed';cls='sw-warn';}
    }
    return E('div',{class:'sw-site'+(success?' sw-site-success':'')},[
     E('div',{class:'sw-site-heading'},[E('span',{class:'sw-site-icon'},v[1]),E('strong',{},v[2]),E('span',{class:success?'sw-success-beacon':'sw-idle-beacon','aria-label':success?'Recent successful connection':r&&r.ok?'Last check passed':'No verified connection'})]),
     E('div',{class:'sw-site-status '+cls,role:'status',title:r&&(r.reason||r.error)||''},label),
     E('div',{class:'sw-sub'},r&&r.pending?'Updating…':r&&r.received_at?'Checked '+new Date(r.received_at).toLocaleTimeString():'HTTPS check · '+(route==='tunnel'?'Tunnel':'Direct'))
    ]);
   })));
  }
  drawService();drawIdentity();drawQuick();drawStatus();drawPing();drawPool();
  poll.add(function(){if(!serviceBusy&&!adguardBusy)return reload();},120);
  poll.add(function(){if(!serviceBusy&&!adguardBusy&&ready(data))return sampleProxy();},120);
  poll.add(sampleSwitch,10);
  if(ready(data))refreshConnection();
  poolDisclosure.appendChild(poolPanel);var body=E('div',{},[notices,livePanel,poolDisclosure]);
  return sw.layout('overview','Connection dashboard','Your tunnel. One clear view.',body,[sw.button('Backup / restore',function(){sw.backupModal(reload);},'ghost'),sw.button('Add via link',function(){sw.importModal(reload);},'primary')]);
 },handleSaveApply:null,handleSave:null,handleReset:null
});
