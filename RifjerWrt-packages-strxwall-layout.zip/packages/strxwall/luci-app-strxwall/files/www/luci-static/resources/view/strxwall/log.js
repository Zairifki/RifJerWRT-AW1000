'use strict';
'require view';
'require strxwall.common as sw';

return view.extend({
 load:function(){return sw.api('logs');},
 render:function(initial){
  var summary=E('pre',{class:'sw-log'});
  var details=E('div',{hidden:true});
  var report='';
  function draw(data){
   var resources=data.resources||{};
   report=[
    'STRXWall V1 '+(data.package_version||''),
    'Service: '+(data.running?'Running':'Stopped'),
    'Available RAM: '+(resources.mem_available_kib==null?'Unavailable':Math.round(resources.mem_available_kib/1024)+' MiB'),
    'PassWall Xray: '+(resources.passwall_xray?'Detected':'Not detected'),
    '',
    data.summary||'No startup attempt recorded.'
   ].join('\n');
   summary.textContent=report;
  }
  function refresh(){
   return sw.api('logs').then(function(data){draw(data);details.hidden=true;details.replaceChildren();});
  }
  function loadDetails(){
   return sw.api('logs',{details:true}).then(function(data){
    var items=[
     ['Listener startup',data.startup],['Config generation',data.generate],['Config validation',data.check],['LAN DNS',data.dns],
     ['IPv6 guard',data.ipv6_guard],['Firewall',data.firewall],['Time sync',data.time],
     ['Package proxy',data.opkg_proxy],['Automatic switching',data.maintenance],
     ['Temporary Core generation',data.probe_generate],['Temporary Core validation',data.probe_check],
     ['Temporary Core runtime',data.probe]
    ].filter(function(item){return item[1];});
    details.replaceChildren.apply(details,items.map(function(item){
     return E('div',{class:'sw-card'},[E('h3',{},item[0]),E('pre',{class:'sw-log'},item[1])]);
    }));
    if(!items.length)details.appendChild(E('p',{class:'sw-muted'},'No detailed diagnostics recorded.'));
    details.hidden=false;
   });
  }
  function copy(){
   if(!navigator.clipboard)throw Error('Clipboard unavailable. Select and copy the startup summary.');
   return navigator.clipboard.writeText(report).then(function(){sw.notify('Diagnostics copied.');});
  }
  function debug(){
   return sw.api('debug_next_start').then(function(){sw.notify('Debug armed for one config check. Start or restart within two minutes.');});
  }
  draw(initial);
  return sw.layout('log','Service logs','Latest startup attempt',E('div',{},[summary,details]),[
   sw.button('Refresh',refresh,'ghost'),sw.button('Show details',loadDetails,'ghost'),sw.button('Debug next start',debug,'ghost'),
   sw.button('Copy diagnostics',copy,'primary')
  ]);
 },
 handleSaveApply:null,handleSave:null,handleReset:null
});
