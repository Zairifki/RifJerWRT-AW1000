/* SJCL AES-GCM/PBKDF2 fallback for browsers without secure-context Web Crypto. */
'use strict';
importScripts('sjcl.js');
function bits(a){var h='';new Uint8Array(a).forEach(function(v){h+=('0'+v.toString(16)).slice(-2);});return sjcl.codec.hex.toBits(h);}
function bytes(a){var h=sjcl.codec.hex.fromBits(a),v=new Uint8Array(h.length/2);for(var i=0;i<v.length;i++)v[i]=parseInt(h.slice(i*2,i*2+2),16);return v;}
self.onmessage=function(e){try{var d=e.data,k=sjcl.misc.pbkdf2(d.password,bits(d.salt),d.count,256),aes=new sjcl.cipher.aes(k),out=sjcl.mode.gcm[d.operation](aes,bits(d.data),bits(d.iv),sjcl.codec.utf8String.toBits('strxwall-encrypted-backup:1'),128);k.fill(0);self.postMessage({data:bytes(out)});}catch(e){self.postMessage({error:'Encryption operation failed.'});}finally{self.close();}};
