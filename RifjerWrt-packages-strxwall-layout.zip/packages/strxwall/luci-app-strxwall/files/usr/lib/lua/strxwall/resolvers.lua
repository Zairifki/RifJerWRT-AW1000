local M={}
M.servers={cloudflare='1.1.1.1',cloudflare6='2606:4700:4700::1111',google='8.8.8.8',google6='2001:4860:4860::8888',quad9='9.9.9.9',quad96='2620:fe::fe',adguard='94.140.14.14',adguard6='2a10:50c0::ad1:ff',cloudflare_doh='https+local://1.1.1.1/dns-query'}
M.labels={cloudflare='Cloudflare IPv4',cloudflare6='Cloudflare IPv6',google='Google IPv4',google6='Google IPv6',quad9='Quad9 IPv4',quad96='Quad9 IPv6',adguard='AdGuard IPv4',adguard6='AdGuard IPv6',cloudflare_doh='Cloudflare DoH',custom='Custom DNS',system='Router system'}
function M.ipv4(v)
 if type(v)~='string' then return false end
 local a,b,c,d=v:match('^(%d+)%.(%d+)%.(%d+)%.(%d+)$')
 if not a then return false end
 for _,part in ipairs({a,b,c,d}) do if #part>3 or tonumber(part)>255 or (#part>1 and part:sub(1,1)=='0') then return false end end
 return true
end
function M.ipv6(v)
 if type(v)~='string' or #v>45 or not v:find(':',1,true) then return false end
 if v:find('.',1,true) then
  local prefix,tail=v:match('^(.*:)([^:]+)$')
  if not prefix or not M.ipv4(tail) then return false end
  v=prefix..'ffff:ffff'
 end
 if v:find('[^%x:]') or v:find(':::',1,true) then return false end
 local left,right=v:match('^(.-)::(.-)$')
 local function count(s)
  if s=='' then return 0 end
  if s:sub(1,1)==':' or s:sub(-1)==':' then return nil end
  local n=0;for part in s:gmatch('[^:]+') do if #part>4 then return nil end;n=n+1 end
  return n
 end
 if left then
  if right:find('::',1,true) then return false end
  local a,b=count(left),count(right);return a~=nil and b~=nil and a+b<8
 end
 return count(v)==8
end
function M.address(v) return M.ipv4(v) or M.ipv6(v) end
function M.node(provider,custom)
 provider=provider or 'system'
 if provider=='system' then return nil end
 if provider=='custom' then if not M.address(custom) then error('Enter a valid custom DNS IPv4 or IPv6 address.',0) end;return custom end
 if not M.servers[provider] then error('Invalid node-server DNS provider.',0) end
 return M.servers[provider]
end
function M.lan(provider,custom)
 provider=provider or 'cloudflare'
 if provider=='system' or provider=='cloudflare_doh' then error('Choose an IPv4 or IPv6 LAN DNS server.',0) end
 local address=M.node(provider,custom)
 return (M.ipv6(address) and '['..address..']' or address)..':53',M.labels[provider]
end
return M
