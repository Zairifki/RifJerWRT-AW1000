-- Persistent preferences remain separate from the effective AdGuard override.
local R=require 'strxwall.resolvers'
local J=require 'luci.jsonc'
local M={}
M.keys={'dns_provider','dns_custom','lan_dns_server','lan_dns_custom','lan_dns','dns_ip_mode'}
function M.mode(u)
 local mode=u:get('strxwall','main','dns_ip_mode')
 if not mode then return nil end -- retain legacy address selections on upgrade
 if not ({ipv4=true,ipv6=true,dual=true})[mode] then error('Invalid DNS IP mode.',0) end
 return mode
end
function M.addresses(provider,custom,mode)
 if provider=='system' then return nil end
 local address=R.node(provider,custom)
 if not mode then return {address} end
 local base=provider:gsub('6$','')
 if provider=='cloudflare_doh' then
  local v4='https+local://1.1.1.1/dns-query';local v6='https+local://[2606:4700:4700::1111]/dns-query'
  return mode=='dual' and {v4,v6} or {mode=='ipv6' and v6 or v4}
 end
 if provider=='custom' then
  if mode=='dual' then error('Dual-stack DNS requires a provider with IPv4 and IPv6 addresses.',0) end
  if (mode=='ipv6')~=R.ipv6(address) then error('Custom DNS address does not match DNS IP mode.',0) end
  return {address}
 end
 local v4=R.servers[base];local v6=R.servers[base..'6']
 if not v4 or not v6 then error('DNS provider does not support this IP mode.',0) end
 return mode=='dual' and {v4,v6} or {mode=='ipv6' and v6 or v4}
end
function M.effective(u)
 local enabled=u:get('strxwall','main','adguard_enabled')=='1'
 local mode=M.mode(u)
 local node=enabled and 'adguard' or (u:get('strxwall','main','dns_provider') or 'system')
 local lan=enabled and 'adguard' or (u:get('strxwall','main','lan_dns_server') or 'cloudflare')
 local selected=enabled and (mode or 'ipv4') or mode
 return {enabled=enabled,mode=selected or 'legacy',node=M.addresses(node,u:get('strxwall','main','dns_custom'),selected),lan=M.addresses(lan,u:get('strxwall','main','lan_dns_custom'),selected),label=enabled and 'AdGuard DNS' or ((R.labels[lan] or lan):gsub(' IPv[46]$','')),node_label=enabled and 'AdGuard DNS' or ((R.labels[node] or node):gsub(' IPv[46]$',''))}
end
function M.toggle(u,on)
 local active=u:get('strxwall','main','adguard_enabled')=='1'
 if on and not active then
  local saved={version=1,values={}}
  for _,k in ipairs(M.keys) do saved.values[k]=u:get('strxwall','main',k) or false end
  u:set('strxwall','main','adguard_saved',J.stringify(saved))
  u:set('strxwall','main','adguard_enabled','1')
  u:set('strxwall','main','lan_dns','1')
 elseif not on and active then
  local saved=J.parse(u:get('strxwall','main','adguard_saved') or '')
  if type(saved)~='table' or saved.version~=1 or type(saved.values)~='table' then error('Saved DNS settings are unavailable; refusing to discard them.',0) end
  for _,k in ipairs(M.keys) do local v=saved.values[k];if v==false or v==nil then u:delete('strxwall','main',k) else u:set('strxwall','main',k,v) end end
  u:set('strxwall','main','adguard_enabled','0');u:delete('strxwall','main','adguard_saved')
 end
 if u:commit('strxwall')==false then error('Unable to save DNS preferences.',0) end
end
return M
