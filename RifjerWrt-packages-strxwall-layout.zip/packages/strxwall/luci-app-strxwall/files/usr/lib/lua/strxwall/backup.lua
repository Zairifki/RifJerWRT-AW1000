-- Own configuration only. Encryption happens in the browser, never in this helper.
local fs=require 'nixio.fs'
local json=require 'luci.jsonc'
local sys=require 'luci.sys'
local nixio=require 'nixio'
local M={}
local root='/var/run/strxwall'
local path=root..'/restore-upload.json'
local max=524288
local function fail(s) error(s,0) end
local function validate(v)
 if type(v)~='table' or v.format~='strxwall-config' or v.version~=1 or type(v.sections)~='table' or #v.sections>2001 then fail('Unsupported STRXWall backup.') end
 for key in pairs(v.sections) do if type(key)~='number' or key%1~=0 or key<1 or key>#v.sections then fail('Invalid section list.') end end
 local names,main,nodes={},0,0
 for _,s in ipairs(v.sections) do
  if type(s)~='table' or type(s.name)~='string' or #s.name>100 or not s.name:match('^[%w_]+$') or names[s.name] or type(s.options)~='table' then fail('Invalid configuration section.') end
  names[s.name]=true
  if s.type=='global' and s.name=='main' then main=main+1 elseif s.type=='node' and s.name~='main' then nodes=nodes+1 else fail('Backup contains an unsupported configuration section.') end
  local count=0
  for k,value in pairs(s.options) do
   count=count+1
   if count>150 or type(k)~='string' or not k:match('^[%w_]+$') or #k>100 then fail('Invalid configuration option.') end
   local function scalar(x) return type(x)=='string' and #x<=65536 and not x:find('%z') end
   if type(value)=='table' then
    if #value>2000 then fail('Configuration list is too large.') end
    for _,x in ipairs(value) do if not scalar(x) then fail('Invalid list value.') end end
    for k2 in pairs(value) do if type(k2)~='number' or k2<1 or k2>#value or k2%1~=0 then fail('Invalid list index.') end end
   elseif not scalar(value) then fail('Invalid configuration value.') end
  end
 end
 if main~=1 then fail('Backup must contain one main configuration section.') end
 return nodes
end
M.validate=validate
function M.cancel()
 fs.remove(path);fs.remove(root..'/restore-ready.json')
 local dir=root..'/restore-config';fs.remove(dir..'/input');fs.remove(dir..'/strxwall_restore');fs.remove(dir..'/delta/strxwall_restore');fs.rmdir(dir..'/delta');fs.rmdir(dir)
 fs.remove('/etc/config/strxwall.restore.tmp')
end
function M.cleanup()
 local ready=json.parse(fs.readfile(root..'/restore-ready.json') or '')
 local stamp=ready and ready.created_at
 if not stamp and fs.stat then local st=fs.stat(path);stamp=st and st.mtime end
 if stamp and os.time()-stamp>300 then M.cancel() end
end
function M.export(u)
 local v={format='strxwall-config',version=1,created_at=os.time(),sections={}}
 u:foreach('strxwall',nil,function(s)
  if (s['.type']=='global' and s['.name']=='main') or s['.type']=='node' then
   local row={type=s['.type'],name=s['.name'],options={}}
   for k,value in pairs(s) do if k:sub(1,1)~='.' then row.options[k]=value end end
   v.sections[#v.sections+1]=row
  end
 end)
 validate(v)
 local raw=json.stringify(v)
 if #raw>max then fail('Backup exceeds the 512 KiB configuration limit.') end
 return {config=v}
end
function M.upload(p)
 nixio.umask('077');fs.mkdir(root,'700');fs.chmod(root,'700')
 local chunk=p.chunk
 if type(chunk)~='string' or #chunk>45000 or type(p.offset)~='number' or p.offset%1~=0 or p.offset<0 then fail('Invalid restore upload.') end
 local old=p.offset==0 and '' or fs.readfile(path)
 if not old or #old~=p.offset or #old+#chunk>max then fail('Restore upload changed or exceeds 512 KiB. Start again.') end
 if p.offset==0 then fs.remove(root..'/restore-ready.json') end
 local raw=old..chunk
 if not fs.writefile(path,raw) then fail('Unable to stage restore data.') end
 if not p.final then return {offset=#raw} end
 local v=json.parse(raw);local nodes=validate(v)
 local id=tostring(os.time())..'-'..tostring(nixio.getpid())
 if not fs.writefile(root..'/restore-ready.json',json.stringify({id=id,size=#raw,created_at=os.time()})) then fail('Unable to stage restore preview.') end
 return {id=id,nodes=nodes,sections=#v.sections,bytes=#raw}
end
function M.apply(p)
 local ready=json.parse(fs.readfile(root..'/restore-ready.json') or '')
 if type(p.id)~='string' or not ready or ready.id~=p.id or os.time()-(ready.created_at or 0)>300 then fail('Restore preview expired. Choose the backup again.') end
 local raw=fs.readfile(path)
 if not raw or #raw~=ready.size then fail('Staged restore changed. Start again.') end
 local v=json.parse(raw);local nodes=validate(v)
 local dir=root..'/restore-config'
 nixio.umask('077');fs.mkdir(dir,'700')
 local delta=dir..'/delta';fs.mkdir(delta,'700')
 local quote=require('luci.util').shellquote
 local lines={}
 for _,section in ipairs(v.sections) do
  if section.type=='global' then section.options.enabled='0' end
  lines[#lines+1]='config '..quote(section.type)..' '..quote(section.name)
  for key,value in pairs(section.options) do
   if type(value)=='table' then for _,entry in ipairs(value) do lines[#lines+1]=' list '..quote(key)..' '..quote(entry) end
   else lines[#lines+1]=' option '..quote(key)..' '..quote(value) end
  end
 end
 if not fs.writefile(dir..'/input',table.concat(lines,'\n')..'\n') then fail('Unable to prepare configuration.') end
 -- Use a different package name as well as an isolated config/save directory.
 -- Modern luci.model.uci ignores custom directories, so it must not stage this.
 if sys.call('uci -c '..dir..' -t '..delta..' import strxwall_restore < '..dir..'/input >/dev/null 2>&1')~=0 or sys.call('uci -c '..dir..' -t '..delta..' commit strxwall_restore >/dev/null 2>&1')~=0 then fail('UCI rejected the restored configuration. Current settings retained.') end
 local config=fs.readfile(dir..'/strxwall_restore');local original=fs.readfile('/etc/config/strxwall')
 if not config or not original then fail('Unable to read configuration for restore.') end
 if not fs.writefile('/etc/strxwall-before-restore',original) or not fs.writefile('/etc/config/strxwall.restore.tmp',config) then fail('Unable to save recovery copy. Current configuration retained.') end
 fs.chmod('/etc/strxwall-before-restore','600');fs.chmod('/etc/config/strxwall.restore.tmp','600')
 if sys.call('/etc/init.d/strxwall stop >/dev/null 2>&1')~=0 then fail('Unable to stop STRXWall. Current configuration retained.') end
 if not fs.rename('/etc/config/strxwall.restore.tmp','/etc/config/strxwall') then fail('Unable to replace configuration; original retained. Restart STRXWall manually.') end
 fs.chmod('/etc/config/strxwall','600')
 fs.remove(path);fs.remove(root..'/restore-ready.json');fs.remove(dir..'/strxwall_restore');fs.remove(dir..'/input');fs.remove(delta..'/strxwall_restore');fs.rmdir(delta);fs.rmdir(dir)
 return {nodes=nodes,stopped=true}
end
return M
