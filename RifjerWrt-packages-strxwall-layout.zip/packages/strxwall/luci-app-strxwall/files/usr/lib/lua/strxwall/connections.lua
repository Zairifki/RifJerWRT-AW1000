local M={}
local resolvers=require 'strxwall.resolvers'
local shellquote=require('luci.util').shellquote

function M.reverse(ip)
 if not resolvers.ipv4(ip) then return '' end
 local a,b,c,d=ip:match('^(%d+)%.(%d+)%.(%d+)%.(%d+)$')
 local query=table.concat({d,c,b,a,'in-addr','arpa'},'.')
 local file=io.popen('timeout 2 nslookup -type=PTR '..query..' 2>/dev/null','r')
 if not file then return '' end
 local hostname=''
 for line in file:lines() do
  local name=line:match('name%s*=%s*([%w_.%-]+)') or line:match('^Name:%s*([%w_.%-]+)')
  if name then hostname=name:gsub('%.$','');break end
 end
 file:close()
 return hostname
end

function M.dns_reply(line)
 local client,question,answers=line:match('%s[%x%.:]+%.53 > ([%x%.:]+)%.%d+:.-%s[%a%d]+%?%s+([%w_.%-]+)%.%s+(.*)')
 if not client or not resolvers.address(client) then return nil end
 local results={}
 for name,kind,ip in answers:gmatch('([%w_.%-]+)%.%s+(A+A*)%s+([%x%.:]+)') do
  if (kind=='A' or kind=='AAAA') and name:lower()==question:lower() and resolvers.address(ip) then
   results[#results+1]={client=client,domain=question:lower(),ip=ip}
  end
 end
 return results
end

function M.domains(device)
 if not device or #device>15 or not device:match('^[%w_.][%w_.:%-]*$') then return {},'LAN interface is unavailable.' end
 local file=io.popen("command -v tcpdump >/dev/null && timeout 2 tcpdump -p -i "..shellquote(device).." -nn -l -vv -s 1500 -c 80 'udp src port 53' 2>&1",'r')
 if not file then return {},'DNS capture is unavailable.' end
 local replies,started={},false
 for line in file:lines() do
  if line:find('listening on ',1,true) then started=true end
  for _,reply in ipairs(M.dns_reply(line) or {}) do
   if #replies<256 then replies[#replies+1]=reply end
  end
 end
 file:close()
 return replies,not started and 'DNS estimates require a working tcpdump on the LAN interface.' or nil
end

function M.parse(line)
 if not line:match('%f[%w]tcp%f[%W]') or not line:match('%f[%w]ESTABLISHED%f[%W]') then return nil end
 local source,destination,sport,dport,reply_source,_,reply_port=line:match(
  'src=(%S+) dst=(%S+) sport=(%d+) dport=(%d+).-src=(%S+) dst=(%S+) sport=(%d+)')
 if not source or (reply_port~='12379' and reply_port~='12380') or reply_source==destination then return nil end
 return {source=source,source_port=tonumber(sport),destination=destination,port=tonumber(dport),protocol='TCP'}
end

function M.sample()
 local leases={}
 local lease_file=io.open('/tmp/dhcp.leases','r')
 if lease_file then
  for line in lease_file:lines() do
   local ip,name=line:match('^%S+%s+%S+%s+(%S+)%s+(%S+)')
   if ip and name~='*' then leases[ip]=name end
  end
  lease_file:close()
 end
 local file=io.open('/proc/net/nf_conntrack','r')
 local available=file~=nil
 if not file then
  file=io.popen("conntrack -L -f ipv4 -p tcp --reply-port-src 12379 2>/dev/null && echo OK; conntrack -L -f ipv6 -p tcp --reply-port-src 12380 2>/dev/null && echo OK",'r')
 end
 local rows={}
 if not file then return rows,false,false end
 local capped=false
 for line in file:lines() do
  if line=='OK' then available=true end
  local row=M.parse(line)
  if row then
   if #rows==100 then capped=true;break end
   row.device=leases[row.source]
   rows[#rows+1]=row
  end
 end
 file:close()
 return rows,capped,available or #rows>0
end

return M
