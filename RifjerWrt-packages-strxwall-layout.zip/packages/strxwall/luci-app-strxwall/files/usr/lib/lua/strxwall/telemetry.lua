local fs=require 'nixio.fs'
local M={}
function M.sample(device)
 device=device or 'br-lan'
 if #device>15 or not device:match('^[%w_%.:%-]+$') or device:find('..',1,true) then error('Invalid telemetry interface',0) end
 local stat=fs.readfile('/proc/stat') or ''
 local cpu=stat:match('^cpu%s+([^\n]+)')
 local values={};for n in (cpu or ''):gmatch('%d+') do values[#values+1]=tonumber(n) end
 local total=0;for i=1,math.min(8,#values) do total=total+values[i] end
 local mem=fs.readfile('/proc/meminfo') or ''
 local function memory(k) return tonumber(mem:match(k..':%s+(%d+)')) end
 local memtotal=memory('MemTotal');local available=memory('MemAvailable')
 if not available and memory('MemFree') then available=memory('MemFree')+(memory('Buffers') or 0)+(memory('Cached') or 0) end
 local function bytes(direction)
  return tonumber(fs.readfile('/sys/class/net/'..device..'/statistics/'..direction..'_bytes') or '')
 end
 return {device=device,uptime=tonumber((fs.readfile('/proc/uptime') or ''):match('^[%d.]+')),
  cpu_total=#values>=4 and total or nil,cpu_idle=#values>=4 and values[4]+(values[5] or 0) or nil,
  memory_total_kb=memtotal,memory_available_kb=available,
  memory_percent=memtotal and memtotal>0 and available and math.max(0,math.min(100,100*(1-available/memtotal))) or nil,
  rx_bytes=bytes('rx'),tx_bytes=bytes('tx'),checked_at=os.time()}
end
return M
