local M={}
local json=require 'luci.jsonc'
local function bad(msg) error(msg,0) end
function M.decode(s)
 s=(s or ''):gsub('%-','+'):gsub('_','/'):gsub('%s','')
 if s:find('[^A-Za-z0-9+/=]') or #s%4==1 then bad('Invalid base64') end
 local alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
 local map={};for i=1,#alphabet do map[alphabet:sub(i,i)]=i-1 end
 local buffer,bits,out=0,0,{}
 for c in s:gmatch('.') do
  if c=='=' then break end
  buffer=buffer*64+map[c];bits=bits+6
  if bits>=8 then bits=bits-8;local byte=math.floor(buffer/2^bits);out[#out+1]=string.char(byte);buffer=buffer%2^bits end
 end
 return table.concat(out)
end
local function dec(s)
 s=s or ''
 if s:gsub('%%[A-Fa-f0-9][A-Fa-f0-9]',''):find('%%') then bad('Invalid percent encoding') end
 return (s:gsub('%%(%x%x)',function(h) return string.char(tonumber(h,16)) end))
end
local function port(v)
 local p=tonumber(v);if not p or p<1 or p>65535 or p%1~=0 then bad('Invalid port') end;return p
end
local function hostport(s)
 local h,p=s:match('^%[([^%]]+)%]:(%d+)$')
 if not h then h,p=s:match('^([^/:@%s]+):(%d+)$') end
 if not h or h=='' then bad('Missing server host or port') end
 return h,port(p)
end
local function query(s)
 local q={};for part in (s or ''):gmatch('[^&]+') do
  local k,v=part:match('^([^=]+)=(.*)$');if k then q[dec(k)]=dec(v) end
 end;return q
end
local function list(s)
 local a={};for v in (s or ''):gmatch('[^,]+') do a[#a+1]=v end;return #a>0 and a or nil
end
local allowed={type=true,encryption=true,flow=true,security=true,sni=true,serverName=true,fp=true,alpn=true,pbk=true,sid=true,spx=true,pqv=true,host=true,path=true,serviceName=true,mode=true,authority=true,headerType=true,allowInsecure=true,insecure=true,aid=true,scy=true}
local function stream(q)
 for k in pairs(q) do if not allowed[k] then bad('Unsupported link option: '..k..'. Use custom outbound JSON to preserve special STRX options.') end end
 if q.allowInsecure=='1' or q.allowInsecure=='true' or q.insecure=='1' or q.insecure=='true' then bad('Insecure TLS links are not imported automatically') end
 if q.headerType and q.headerType~='' and q.headerType~='none' then bad('Unsupported TCP header type') end
 local n=q.type or 'raw';if n=='tcp' then n='raw' end
 if not ({raw=true,ws=true,grpc=true,httpupgrade=true,xhttp=true})[n] then bad('Unsupported transport: '..n) end
 local sec=q.security or 'none'
 if not ({none=true,tls=true,reality=true})[sec] then bad('Unsupported security mode') end
 local s={network=n,security=sec}
 if sec=='tls' then
  s.tlsSettings={allowInsecure=false,serverName=q.sni or q.serverName,fingerprint=q.fp,alpn=list(q.alpn)}
 elseif sec=='reality' then
  if not q.pbk or q.pbk=='' then bad('REALITY public key is missing') end
  s.realitySettings={serverName=q.sni or q.serverName,password=q.pbk,fingerprint=q.fp or 'chrome',shortId=q.sid or '',spiderX=q.spx or '/',mldsa65Verify=q.pqv}
 end
 if n=='ws' then s.wsSettings={path=q.path or '/'};if q.host then s.wsSettings.host=q.host end
 elseif n=='grpc' then s.grpcSettings={serviceName=q.serviceName or '',multiMode=q.mode=='multi',authority=q.authority}
 elseif n=='httpupgrade' then s.httpupgradeSettings={path=q.path or '/',host=q.host}
 elseif n=='xhttp' then s.xhttpSettings={path=q.path or '/',host=q.host,mode=q.mode or 'auto'} end
 return s
end
function M.parse(uri)
 uri=uri:match('^%s*(.-)%s*$')
 local scheme,body=uri:match('^(%a[%w+.-]*)://(.+)$');if not scheme then bad('Not a node link') end
 scheme=scheme:lower()
 local name;body,name=body:match('^(.-)#(.*)$') or body,body:match('#(.*)$')
 name=name and dec(name) or nil
 local out
 if scheme=='vmess' then
  local v=json.parse(M.decode(body));if type(v)~='table' then bad('Invalid VMess JSON') end
  local known={v=true,ps=true,add=true,port=true,id=true,aid=true,scy=true,net=true,type=true,host=true,path=true,tls=true,sni=true,alpn=true,fp=true,allowInsecure=true}
  for k in pairs(v) do if not known[k] then bad('Unsupported VMess field: '..k..'. Use custom outbound JSON.') end end
  if v.tls and v.tls~='' and v.tls~='none' and v.tls~='tls' then bad('Unsupported VMess security mode') end
  if not v.add or not v.id then bad('VMess host or UUID missing') end
  name=(name and name~='' and name) or v.ps
  if tonumber(v.aid or 0)~=0 then bad('Legacy VMess alterId is unsupported') end
  if v.allowInsecure==true or v.allowInsecure=='1' or v.allowInsecure=='true' then bad('Insecure VMess TLS is unsupported') end
  out={protocol='vmess',settings={vnext={{address=v.add,port=port(v.port),users={{id=v.id,alterId=0,security=v.scy or 'auto'}}}}},streamSettings=stream({type=v.net or 'raw',security=v.tls=='tls' and 'tls' or 'none',sni=v.sni,fp=v.fp,alpn=v.alpn,host=v.host,path=v.path,serviceName=v.net=='grpc' and (v.path or '') or nil,headerType=v.type})}
 elseif scheme=='ss' then
  local auth,qs=body:match('^([^?]+)%??(.*)$');local q=query(qs)
  if next(q) then bad('Shadowsocks plugin/extra options require custom JSON') end
  auth=auth:gsub('/$','')
  if not auth:find('@',1,true) then auth=M.decode(auth) end
  local user,server=auth:match('^(.*)@([^@]+)$');if not user then bad('Invalid Shadowsocks link') end
  user=dec(user);if not user:find(':',1,true) then user=M.decode(user) end
  local method,password=user:match('^([^:]+):(.*)$');if not method or password=='' then bad('Missing Shadowsocks credentials') end
  local host,p=hostport(server)
  out={protocol='shadowsocks',settings={servers={{address=host,port=p,method=method,password=password}}}}
 elseif scheme=='vless' or scheme=='trojan' then
  local auth,qs=body:match('^([^?]+)%??(.*)$');local q=query(qs)
  local user,server=auth:match('^(.*)@([^@]+)$');if not user or user=='' then bad('Missing node credentials') end
  server=server:gsub('/$','');local host,p=hostport(server);user=dec(user)
  out={protocol=scheme}
  if scheme=='vless' then
   out.settings={vnext={{address=host,port=p,users={{id=user,encryption=q.encryption or 'none',flow=q.flow}}}}}
  else out.settings={servers={{address=host,port=p,password=user}}};q.security=q.security or 'tls' end
  out.streamSettings=stream(q)
 else bad('Supported links: vless://, vmess://, trojan://, ss://') end
 out.tag='proxy'
 return {name=(name and name~='' and name) or (scheme..' node'),protocol='custom',outbound_json=json.stringify(out),source_link=uri,eligible='1'}
end
function M.batch(text)
 if type(text)~='string' or #text>1048576 then bad('Import must be at most 1 MiB') end
 text=text:gsub('^\239\187\191','')
 if not text:find('://',1,true) then text=M.decode(text) end
 local result={}
 for line in text:gmatch('[^\r\n]+') do
  line=line:match('^%s*(.-)%s*$')
  if line~='' and line:sub(1,1)~='#' then
   if #result>=200 then bad('Maximum 200 nodes per import') end
   local ok,value=pcall(M.parse,line)
   if not ok then bad('Node '..(#result+1)..': '..tostring(value)) end
   result[#result+1]=value
  end
 end
 if #result==0 then bad('No node links found') end
 return result
end
function M.apply(uci,nodes,group)
 local existing={};local added,updated=0,0
 uci:foreach('strxwall','node',function(n) if n.source_link and (n.subscription or '')==(group or '') then existing[n.source_link]=n['.name'] end end)
 for _,n in ipairs(nodes) do
  local id=existing[n.source_link]
  local isnew=not id
  if not id then id=uci:add('strxwall','node');existing[n.source_link]=id;added=added+1 else updated=updated+1 end
  local oldeligible=uci:get('strxwall',id,'eligible')
  for k,v in pairs(n) do uci:set('strxwall',id,k,v) end
  if isnew and uci:get('strxwall','main','failover_pool_explicit')=='1' then uci:set('strxwall',id,'eligible','0') end
  if oldeligible=='0' then uci:set('strxwall',id,'eligible','0') end
  if group then uci:set('strxwall',id,'subscription',group) end
 end
 return added,updated
end
return M
