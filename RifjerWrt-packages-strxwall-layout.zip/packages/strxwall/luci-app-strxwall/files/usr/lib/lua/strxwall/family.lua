local M={}
function M.endpoint(out)
 local settings=out.settings or {}
 local server=(settings.vnext or settings.servers or {})[1]
 return type(server)=='table' and server.address or nil
end
function M.literal(host)
 if type(host)~='string' then return nil end
 if host:find(':',1,true) then return 'ipv6' end
 if host:match('^%d+%.%d+%.%d+%.%d+$') then return 'ipv4' end
 return nil
end
function M.configure(out,config,family,custom_dns)
 if not ({auto=true,ipv4=true,ipv6=true})[family] then error('Invalid connection IP family',0) end
 local literal=M.literal(M.endpoint(out))
 if family~='auto' and literal and literal~=family then error('Server IP literal does not match requested '..family..' family',0) end
 out.streamSettings=out.streamSettings or {}
 out.streamSettings.sockopt=out.streamSettings.sockopt or {}
 local sock=out.streamSettings.sockopt
 if family=='auto' and not custom_dns then
  sock.domainStrategy='AsIs';sock.happyEyeballs=nil
 else
  config.dns=config.dns or {servers={'localhost'}}
  config.dns.queryStrategy=family=='ipv4' and 'UseIPv4' or family=='ipv6' and 'UseIPv6' or 'UseIP'
  sock.domainStrategy=family=='ipv4' and 'ForceIPv4' or family=='ipv6' and 'ForceIPv6' or 'ForceIP'
  if family=='auto' and not sock.dialerProxy then
   sock.happyEyeballs={tryDelayMs=250,prioritizeIPv6=false,interleave=1,maxConcurrentTry=2}
  else sock.happyEyeballs=nil end
 end
end
function M.classify(v4,v6)
 if v4 and v6 then return 'Dual-stack' elseif v4 then return 'IPv4 only' elseif v6 then return 'IPv6 only' end
 return 'No working family'
end
return M
