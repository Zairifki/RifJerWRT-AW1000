local fs=require 'nixio.fs'
local nixio=require 'nixio'
local sys=require 'luci.sys'
local util=require 'luci.util'
local json=require 'luci.jsonc'
local familylib=require 'strxwall.family'
local uci=require('luci.model.uci').cursor()
local root='/var/run/strxwall'
local function exec(cmd) return sys.exec(cmd) or '' end
nixio.umask("077")
fs.mkdir(root,"700")
local lock=root..'/maintenance.lock'
local function shell(v) return util.shellquote(tostring(v)) end
local function live(pid) return pid and pid:match('^%d+$') and sys.call('kill -0 '..pid..' 2>/dev/null')==0 end
if not fs.mkdir(lock,"700") then
 local pid=fs.readfile(lock..'/pid')
 if live(pid) then os.exit(0) end
 fs.remove(lock..'/pid');fs.rmdir(lock)
 if not fs.mkdir(lock,"700") then os.exit(0) end
end
fs.writefile(lock..'/pid',tostring(nixio.getpid()))
local function cleanup_probe() return sys.call('/usr/libexec/strxwall-probe-cleanup')==0 end
cleanup_probe()
local state=json.parse(fs.readfile(root..'/maintenance.json') or '') or {failures=0,last_switch=0}
state.subscriptions=nil
local function report(s)
 fs.writefile(root..'/maintenance-status',s)
 local old=fs.readfile(root..'/maintenance.log') or ''
 if #old>24000 then old=old:sub(-12000) end
 fs.writefile(root..'/maintenance.log',old..os.date('%Y-%m-%d %H:%M:%S')..' '..s..'\n')
end
local function curltest(port,url)
 local cmd='/usr/bin/curl --silent --show-error --head --noproxy '..shell('')..' --socks5-hostname 127.0.0.1:'..port..' --proto '..shell('=https')..' --connect-timeout 5 --max-time 8 --output /dev/null --write-out '..shell('%{http_code} %{time_total}')..' --url '..shell(url)..' 2>/dev/null'
 local output=exec(cmd)
 local code,elapsed=output:match('^(%d+)%s+([%d.]+)')
 code=tonumber(code) or tonumber(output)
 return code and code>=200 and code<400,elapsed and tonumber(elapsed)*1000 or nil
end
local function probe(id,url,family,check_exit6,verify_backup)
 cleanup_probe()
 fs.mkdir(root..'/probe',"700")
 local wanted=family or uci:get('strxwall','main','ip_family') or 'auto'
 local name=uci:get('strxwall',id,'name') or id
 local function result(ok,stage,reason,ms,exit6)
  local status={node=id,name=name,family=wanted,ok=ok==true,stage=stage,reason=reason,checked_at=os.time()}
  fs.writefile(root..'/probe/result.json',json.stringify(status))
  if not ok then report('Probe '..name..' ['..wanted..'] '..stage..': '..reason) end
  return ok,ms,exit6,status
 end
 fs.remove(root..'/probe/error');fs.remove(root..'/probe/core.pid')
 fs.writefile(root..'/probe/core.log','');fs.writefile(root..'/probe/check.log','')
 local generated=sys.call('/usr/bin/lua /usr/libexec/strxwall-generate.lua --probe '..shell(id)..' '..shell(wanted)..' >'..root..'/probe/generate.log 2>&1')
 if generated~=0 then return result(false,'generation','Configuration generation failed (exit '..tostring(generated)..'). See temporary core generation diagnostics.') end
 local validated=sys.call('/usr/libexec/strxwall-core run -test -config '..root..'/probe/config.json >'..root..'/probe/check.log 2>&1')
 if validated~=0 then return result(false,'validation','Core validation failed (exit '..tostring(validated)..'). See temporary core validation diagnostics.') end
 local launched=sys.call('( /usr/libexec/strxwall-core run -config '..root..'/probe/config.json </dev/null >'..root..'/probe/core.log 2>&1 & echo $! >'..root..'/probe/core.pid )')
 local pid=(fs.readfile(root..'/probe/core.pid') or ''):match('^%s*(%d+)%s*$')
 if launched~=0 or not pid or tonumber(pid)<2 then cleanup_probe();return result(false,'launch','Temporary core launch failed; no valid PID recorded (exit '..tostring(launched)..').') end
 local ready=false
 for attempt=1,8 do
  if not live(pid) then break end
  if sys.call('/usr/libexec/strxwall-listening 2A81')==0 then ready=true;break end
  nixio.nanosleep(1)
 end
 local ok,ms,exit6=false,nil,nil
 local stage,reason='startup','SOCKS port 10881 was not ready within 8 seconds or the core exited.'
 if ready then
  ok,ms=curltest(10881,url)
  stage='primary_https';reason='Primary HTTPS target failed through the temporary tunnel.'
  if ok and verify_backup then
   local second=url=='https://github.com/' and 'https://www.gstatic.com/generate_204' or 'https://github.com/'
   ok=curltest(10881,second)==true
   stage='verification_https';reason='Second HTTPS target failed through the temporary tunnel.'
  end
  if ok and check_exit6 then exit6=curltest(10881,'https://api6.ipify.org/')==true end
 end
 sys.call('kill '..pid..' 2>/dev/null')
 for attempt=1,5 do if not live(pid) then break end;nixio.nanosleep(0,200000000) end
 if live(pid) then sys.call('kill -KILL '..pid..' 2>/dev/null') end
 cleanup_probe();fs.remove(root..'/probe/core.pid')
 return result(ok,ok and 'passed' or stage,ok and 'Tunnel check passed.' or reason,ms,exit6)
end
local function signature(id)
 local n=uci:get_all('strxwall',id) or {}
 local parts={'probe-v3'}
 for _,k in ipairs({'outbound_json','protocol','address','port','uuid','password','transport','tls','host','sni','path','flow','method','service_name'}) do parts[#parts+1]=n[k] or '' end
 parts[#parts+1]=uci:get('strxwall','main','dns_provider') or 'system'
 parts[#parts+1]=uci:get('strxwall','main','dns_custom') or ''
 for _,key in ipairs({'adguard_enabled','dns_ip_mode','ip_family','core'}) do parts[#parts+1]=uci:get('strxwall','main',key) or '' end
 local joined=table.concat(parts,'|');local hash=0;for i=1,#joined do hash=(hash*31+joined:byte(i))%4294967296 end
 return tostring(hash)
end
local function detect(id)
 if not id or not id:match('^[%w_]+$') or uci:get('strxwall',id)~='node' then error('Invalid detection node',0) end
 local url=uci:get('strxwall','main','probe_url') or 'https://www.gstatic.com/generate_204'
 if not url:match('^https://[^%s]+$') then error('Invalid health-check URL',0) end
 report('Detecting proxy IPv4/IPv6 support: '..(uci:get('strxwall',id,'name') or id))
 local n=uci:get_all('strxwall',id) or {}
 local literal=familylib.literal(n.address)
 if n.protocol=='custom' then local out=json.parse(n.outbound_json or '');literal=type(out)=='table' and familylib.literal(familylib.endpoint(out)) or nil end
 local four,ms4,exit4,status4=false,nil,nil,nil
 local six,ms6,exit6,status6=false,nil,nil,nil
 if literal~='ipv6' then four,ms4,exit4,status4=probe(id,url,'ipv4',true) end
 if literal~='ipv4' then six,ms6,exit6,status6=probe(id,url,'ipv6',not four) end
 local exit_result=exit4;if exit_result==nil then exit_result=exit6 end
 local all=json.parse(fs.readfile(root..'/capabilities.json') or '') or {}
 local infrastructure={generation=true,validation=true,launch=true,startup=true}
 local inconclusive=(status4 and infrastructure[status4.stage]) or (status6 and infrastructure[status6.stage]) or false
 all[id]={ipv4=four==true,ipv6=six==true,ms4=ms4,ms6=ms6,exit_ipv6=exit_result,
  label=(not four and not six and inconclusive) and 'Test unavailable' or familylib.classify(four,six),inconclusive=inconclusive,ipv4_test=status4,ipv6_test=status6,checked_at=os.time(),signature=signature(id)}
 fs.writefile(root..'/capabilities.json',json.stringify(all))
 report('IP-family detection: '..all[id].label..' for '..(uci:get('strxwall',id,'name') or id))
end
local function detect_active()
 if uci:get('strxwall','main','enabled')~='1' or uci:get('strxwall','main','auto_detect')=='0' then return end
 local id=uci:get('strxwall','main','node');if not id or uci:get('strxwall',id)~='node' then return end
 local all=json.parse(fs.readfile(root..'/capabilities.json') or '') or {}
 local old=all[id]
 if old and old.signature==signature(id) and os.time()-(old.checked_at or 0)<900 then return end
 detect(id)
end
local function check_return(current,url,cooldown)
 local target=state.return_node
 if not target or target==current then return false end
 if not target:match('^[%w_]+$') or uci:get('strxwall',target)~='node' then
  state.return_node=nil;state.recovery_passes=0;report('Previous node no longer exists; automatic return cancelled.');return false
 end
 if uci:get('strxwall','main','auto_return')=='0' then state.recovery_passes=0;return false end
 local now=os.time();local previous=tonumber(state.return_checked_at) or 0
 if now>=previous and now-previous<60 then return false end
 state.return_checked_at=now
 local epoch=state.return_epoch or ''
 local passed=probe(target,url,nil,false,true)
 -- Never overwrite a manual selection or a setting changed during the probe.
 uci:unload('strxwall');uci:load('strxwall')
 if (uci:get('strxwall','main','return_epoch') or '')~=epoch then state.return_node=nil;state.return_epoch=uci:get('strxwall','main','return_epoch') or '';state.recovery_passes=0;return false end
 if uci:get('strxwall','main','node')~=current or uci:get('strxwall','main','enabled')~='1' or uci:get('strxwall','main','auto_switch')~='1' or uci:get('strxwall','main','auto_return')=='0' or uci:get('strxwall',target)~='node' then
  state.recovery_passes=0;return false
 end
 if not passed then state.recovery_passes=0;report('Previous node recovery check failed; staying on the active backup.');return false end
 state.recovery_passes=math.min(3,(tonumber(state.recovery_passes) or 0)+1)
 report('Previous node recovery passed ('..state.recovery_passes..'/3): '..(uci:get('strxwall',target,'name') or target))
 if state.recovery_passes<3 then return false end
 if now-(tonumber(state.last_switch) or 0)<cooldown then report('Previous node recovered; waiting for switch cooldown.');return false end
 uci:set('strxwall','main','node',target)
 uci:delete('strxwall','main','return_target');uci:delete('strxwall','main','return_active');uci:delete('strxwall','main','return_since')
 if uci:commit('strxwall')==false then report('Unable to save recovered node selection; active backup retained.');return false end
 state.last_event={kind='return',from=current,to=target,name=uci:get('strxwall',target,'name') or target,reason='Previous node passed three consecutive recovery checks and cooldown',checked_at=now}
 state.current=target;state.failures=0;state.last_switch=now;state.offset=0;state.return_node=nil;state.recovery_passes=0;state.return_checked_at=0
 report('Returned to recovered previous node: '..(uci:get('strxwall',target,'name') or target))
 return true
end
local function autoswitch()
 if uci:get('strxwall','main','enabled')~='1' or uci:get('strxwall','main','auto_switch')~='1' then state.recovery_passes=0;return false end
 local current=uci:get('strxwall','main','node')
 if not state.return_initialized then
  state.return_initialized=true;state.return_epoch=uci:get('strxwall','main','return_epoch') or ''
  local event=state.last_event
  local remembered=uci:get('strxwall','main','return_target')
  if remembered and uci:get('strxwall','main','return_active')==current and remembered~=current and uci:get('strxwall',remembered)=='node' then state.return_node=remembered;state.current=current;state.last_switch=tonumber(uci:get('strxwall','main','return_since')) or state.last_switch or 0 end
  if not state.return_node and state.current==current and event and event.to==current and event.kind~='return' and event.from~=current and uci:get('strxwall',event.from)=='node' then state.return_node=event.from end
 end
 if state.current~=current then
  state.current=current;state.failures=0;state.return_node=nil;state.recovery_passes=0;state.return_checked_at=0
 end
 local epoch=uci:get('strxwall','main','return_epoch') or ''
 if (state.return_epoch or '')~=epoch then state.return_node=nil;state.recovery_passes=0;state.return_checked_at=0 end
 state.return_epoch=epoch
 local cooldown=math.max(60,tonumber(uci:get('strxwall','main','switch_cooldown')) or 180)
 local url=uci:get('strxwall','main','probe_url') or 'https://www.gstatic.com/generate_204'
 if not url:match('^https://[^%s]+$') or #url>=2048 then report('Invalid health-check URL.');return false end
 local healthy=curltest(10879,url)
 if not healthy then local second=url=='https://github.com/' and 'https://www.gstatic.com/generate_204' or 'https://github.com/';healthy=curltest(10879,second) end
 if healthy then
  state.failures=0;state.offset=0;state.last_check={ok=true,checked_at=os.time()};report('Active tunnel health check passed.');return check_return(current,url,cooldown)
 end
 state.failures=(tonumber(state.failures) or 0)+1
 state.last_check={ok=false,checked_at=os.time(),reason='Both HTTPS health targets failed'}
 local limit=math.max(1,math.min(10,tonumber(uci:get('strxwall','main','failure_threshold')) or 3))
 report('Active tunnel check failed ('..state.failures..'/'..limit..').')
 state.recovery_passes=0
 if state.failures<limit or os.time()-(tonumber(state.last_switch) or 0)<cooldown then return false end
 local nodes={}
 uci:foreach('strxwall','node',function(n) if n['.name']~=current and n.eligible~='0' then nodes[#nodes+1]=n end end)
 local ordered=uci:get('strxwall','main','failover_order') or {}
 if type(ordered)=='string' then local parsed={};for id in ordered:gmatch('%S+') do parsed[#parsed+1]=id end;ordered=parsed end
 local priority_key=table.concat(ordered,'|')
 local ranks,original={},{}
 for index,id in ipairs(ordered) do if not ranks[id] then ranks[id]=index end end
 for index,n in ipairs(nodes) do original[n['.name']]=index end
 table.sort(nodes,function(a,b)return (ranks[a['.name']] or 100000+original[a['.name']])<(ranks[b['.name']] or 100000+original[b['.name']])end)
 local ids={};for _,n in ipairs(nodes) do ids[#ids+1]=n['.name'] end
 local signature=table.concat(ids,'|')
 if state.order_signature~=signature then state.offset=0;state.order_signature=signature end
 -- Walk the saved sequence; at most three sequential candidates per pass.
 if #nodes==0 then report('No eligible backup nodes selected. Select another node in the backup pool.');return false end
 local offset=(tonumber(state.offset) or 0)%#nodes
 local attempts=math.min(3,#nodes-offset)
 for step=1,attempts do
  local n=nodes[offset+step]
  report('Testing fallback '..(offset+step)..'/'..#nodes..': '..(n.name or n['.name']))
  if probe(n['.name'],url,nil,false,true) then
   -- Re-read to avoid overriding selection or sequence edits during a probe.
   uci:unload('strxwall');uci:load('strxwall')
   local saved_order=uci:get('strxwall','main','failover_order') or {}
   if type(saved_order)=='string' then local parsed={};for id in saved_order:gmatch('%S+') do parsed[#parsed+1]=id end;saved_order=parsed end
   if table.concat(saved_order,'|')~=priority_key then state.offset=0;report('Backup sequence changed during probing; retrying with the new order.');return false end
   if (uci:get('strxwall','main','return_epoch') or '')~=epoch then state.return_node=nil;state.recovery_passes=0;state.return_epoch=uci:get('strxwall','main','return_epoch') or '';return false end
   if uci:get('strxwall','main','node')~=current or uci:get('strxwall','main','enabled')~='1' or uci:get('strxwall',n['.name'])~='node' or uci:get('strxwall',n['.name'],'eligible')=='0' or uci:get('strxwall','main','auto_switch')~='1' then return false end
   local returnTarget=state.return_node or current
   if n['.name']==returnTarget then returnTarget=nil end
   uci:set('strxwall','main','node',n['.name'])
   if returnTarget then uci:set('strxwall','main','return_target',returnTarget);uci:set('strxwall','main','return_active',n['.name']);uci:set('strxwall','main','return_since',tostring(os.time()))
   else uci:delete('strxwall','main','return_target');uci:delete('strxwall','main','return_active');uci:delete('strxwall','main','return_since') end
   if uci:commit('strxwall')==false then report('Unable to save backup selection. Current node retained.');return false end
   state.return_node=returnTarget
   state.recovery_passes=0;state.return_checked_at=0
   state.last_event={kind='failover',from=current,to=n['.name'],name=n.name or n['.name'],reason='Repeated active-node failures; backup passed two HTTPS targets',checked_at=os.time()}
   state.current=n['.name'];state.failures=0;state.last_switch=os.time();state.offset=0
   report('Switched to verified backup: '..(n.name or n['.name']))
   return true
  end
 end
 state.offset=(offset+attempts)%#nodes
 report('No verified backup among '..attempts..' tested candidate(s). See preceding Probe messages. Current node retained.')
 return false
end
local ok,err=pcall(function()
 if arg and arg[1]=='detect' then detect(arg[2]);return end
 if arg and arg[1]=='test' then
  local id=arg[2]
  if not id or not id:match('^[%w_]+$') or uci:get('strxwall',id)~='node' then error('Invalid test node',0) end
  local url=uci:get('strxwall','main','probe_url') or 'https://www.gstatic.com/generate_204'
  if not url:match('^https://[^%s]+$') then error('Invalid test URL',0) end
  local passed,ms=probe(id,url)
  local tests=json.parse(fs.readfile(root..'/tests.json') or '') or {}
  tests[id]={ok=passed,ms=ms,checked_at=os.time()}
  fs.writefile(root..'/tests.json',json.stringify(tests))
  report('Node tunnel test '..(passed and 'passed' or 'failed')..': '..(uci:get('strxwall',id,'name') or id))
  return
 end
 if arg and arg[1]=='refresh' then error('Subscriptions have been removed.',0) end
 local changed=autoswitch()
 if changed then fs.writefile(root..'/reload','1') elseif not (state.return_node and uci:get('strxwall','main','auto_switch')=='1' and uci:get('strxwall','main','auto_return')~='0') and ((tonumber(state.failures) or 0)==0 or uci:get('strxwall','main','auto_switch')~='1') then detect_active() end
end)
cleanup_probe()
if not ok then report('Maintenance error: '..tostring(err)) end
fs.writefile(root..'/maintenance.json',json.stringify(state))
fs.remove(lock..'/pid');fs.rmdir(lock)
