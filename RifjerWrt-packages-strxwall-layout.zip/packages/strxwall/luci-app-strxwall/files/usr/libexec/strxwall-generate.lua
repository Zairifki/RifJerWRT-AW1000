local uci=require('luci.model.uci').cursor()
local json=require 'luci.jsonc'
local fs=require 'nixio.fs'
local familylib=require 'strxwall.family'
local resolvers=require 'strxwall.resolvers'
local probe=arg and arg[1]=='--probe'
local dir=probe and '/var/run/strxwall/probe' or '/var/run/strxwall'
local function fail(msg) error(msg,0) end
local function port(v) local p=tonumber(v);if not p or p<1 or p>65535 or p%1~=0 then fail('Invalid server port') end;return p end
local function required(v,label) if not v or v=='' then fail('Missing '..label) end;return v end
local function build()
 local id=required(probe and arg[2] or uci:get('strxwall','main','node'),'active node')
 if uci:get('strxwall',id)~='node' then fail('Active node not found') end
 local n=uci:get_all('strxwall',id)
 local out={tag='proxy',protocol=n.protocol}
 if n.protocol=='custom' then
  out=json.parse(n.outbound_json or '')
  if type(out)~='table' or type(out.protocol)~='string' or type(out.settings)~='table' then fail('Invalid custom outbound JSON') end
  out.tag='proxy'
 else
  local addr=required(n.address,'server address');local p=port(n.port)
  if n.protocol=='vless' or n.protocol=='vmess' then
   local user={id=required(n.uuid,'UUID')}
   if not user.id:match('^[%x%-]+$') or #user.id~=36 then fail('UUID must have 36 characters') end
   if n.protocol=='vless' then user.encryption='none';local fl=n.flow and n.flow:lower() or '';if fl~='' and fl~='none' and fl~='disable' then user.flow=n.flow end
   else user.security='auto';user.alterId=0 end
   out.settings={vnext={{address=addr,port=p,users={user}}}}
  elseif n.protocol=='trojan' then
   out.settings={servers={{address=addr,port=p,password=required(n.password,'password')}}}
  elseif n.protocol=='shadowsocks' then
   out.settings={servers={{address=addr,port=p,password=required(n.password,'password'),method=required(n.method,'Shadowsocks method')}}}
  else fail('Unsupported protocol') end
  local network=n.transport or 'raw'
  if not ({raw=true,ws=true,grpc=true,httpupgrade=true,xhttp=true})[network] then fail('Unsupported transport') end
  local stream={network=network,security=n.tls=='1' and 'tls' or 'none'}
  if n.tls=='1' then
   stream.tlsSettings={allowInsecure=false}
   if n.sni and n.sni~='' then stream.tlsSettings.serverName=n.sni end
  end
  if network=='ws' then
   stream.wsSettings={path=n.path or '/'}
   if n.host and n.host~='' then stream.wsSettings.host=n.host end
  elseif network=='grpc' then stream.grpcSettings={serviceName=n.service_name or ''}
  elseif network=='httpupgrade' then stream.httpupgradeSettings={path=n.path or '/',host=n.host or ''}
  elseif network=='xhttp' then stream.xhttpSettings={path=n.path or '/',host=n.host or '',mode='auto'} end
  out.streamSettings=stream
 end
 local mode=probe and 'local' or (uci:get('strxwall','main','mode') or 'lan_tcp')
 if mode~='local' and mode~='lan_tcp' and mode~='lan_dual_tcp' then fail('Invalid traffic mode') end
 local device=uci:get('strxwall','main','lan_device') or 'br-lan'
 if #device>15 or not device:match('^[%w_%.:%-]+$') then fail('Invalid LAN device') end
 local loglevel=uci:get('strxwall','main','loglevel') or 'warning'
 if not ({debug=true,info=true,warning=true,error=true})[loglevel] then fail('Invalid log level') end
 local inbounds={
  {tag='socks',listen='127.0.0.1',port=probe and 10881 or 10879,protocol='socks',settings={auth='noauth',udp=false}},
  {tag='http',listen='127.0.0.1',port=probe and 10882 or 10880,protocol='http',settings={allowTransparent=false}}
 }
 if mode=='lan_tcp' or mode=='lan_dual_tcp' then
  inbounds[#inbounds+1]={tag='redirect',listen='0.0.0.0',port=12379,protocol='dokodemo-door',settings={network='tcp',followRedirect=true},streamSettings={sockopt={tproxy='redirect'}}}
 end
 if mode=='lan_dual_tcp' then
  inbounds[#inbounds+1]={tag='redirect6',listen='::',port=12380,protocol='dokodemo-door',settings={network='tcp',followRedirect=true},streamSettings={sockopt={tproxy='redirect',v6only=true}}}
 end
 -- Normalize the deprecated WebSocket Host header without changing transport.
 local ws=out.streamSettings and out.streamSettings.wsSettings
 if ws and type(ws.headers)=='table' then
  for k,v in pairs(ws.headers) do if type(k)=='string' and k:lower()=='host' then if not ws.host then ws.host=v end;ws.headers[k]=nil end end
  if not next(ws.headers) then ws.headers=nil end
 end
 local config={log={loglevel=loglevel},inbounds=inbounds,outbounds={out}}
 local dns=uci:get('strxwall','main','dns_provider') or 'system'
 local policy=require('strxwall.dns_policy').effective(uci)
 if policy.node then
  local servers={}
  for _,v in ipairs(policy.node) do servers[#servers+1]=resolvers.address(v) and ('tcp+local://'..(resolvers.ipv6(v) and '['..v..']' or v)..':53') or v end
  config.dns={servers=servers}
 end
 local selected_family=(probe and arg[3]) or uci:get('strxwall','main','ip_family') or 'ipv4'
 familylib.configure(out,config,selected_family,policy.node~=nil)
 if config.dns then config.dns.queryStrategy='UseIP' end
 local udp=probe and 'direct' or (uci:get('strxwall','main','udp_mode') or (mode=='local' and 'direct' or 'same'))
 if not ({direct=true,same=true,block=true})[udp] then fail('Invalid UDP node selection') end
 if mode=='local' and udp~='direct' then fail('UDP interception requires a LAN routing mode') end
 if udp=='same' then
  inbounds[#inbounds+1]={tag='udp-redirect',listen='0.0.0.0',port=12381,protocol='dokodemo-door',settings={network='udp',followRedirect=true},streamSettings={sockopt={tproxy='tproxy'}}}
  if mode=='lan_dual_tcp' then inbounds[#inbounds+1]={tag='udp-redirect6',listen='::',port=12382,protocol='dokodemo-door',settings={network='udp',followRedirect=true},streamSettings={sockopt={tproxy='tproxy',v6only=true}}} end
  inbounds[#inbounds+1]={tag='udp-check',listen='127.0.0.1',port=10885,protocol='dokodemo-door',settings={network='udp',address='1.1.1.1',port=53}}
 end
 -- Route only public IPv4 NTP through a marked copy of the active node.
 -- A concrete LAN bind keeps UDP reply source addresses stable on multihomed routers.
 local ntp_enabled=not probe and mode~='local' and udp~='block' and uci:get('strxwall','main','ntp_proxy')~='0'
 if ntp_enabled then
  local pipe=io.popen('ip -4 -o addr show dev '..device..' scope global 2>/dev/null')
  local addresses=pipe and pipe:read('*a') or '';if pipe then pipe:close() end
  local address=addresses:match('inet%s+(%d+%.%d+%.%d+%.%d+)/')
  if not address or not resolvers.address(address) then fail('NTP routing requires an IPv4 LAN address on '..device) end
  local function copy(v) if type(v)~='table' then return v end;local r={};for k,x in pairs(v) do r[k]=copy(x) end;return r end
  local ntpout=copy(out);ntpout.tag='proxy-ntp'
  ntpout.streamSettings=ntpout.streamSettings or {};ntpout.streamSettings.sockopt=ntpout.streamSettings.sockopt or {}
  -- Preserve the low bits used by mwan3 while reserving an independent high-bit bypass.
  ntpout.streamSettings.sockopt.mark=1398276096
  config.outbounds[#config.outbounds+1]=ntpout
  inbounds[#inbounds+1]={tag='ntp',listen=address,port=12383,protocol='dokodemo-door',settings={network='udp',address='0.my.pool.ntp.org',port=123}}
  config.routing={rules={{type='field',inboundTag={'ntp'},outboundTag='proxy-ntp'}}}
  if not fs.writefile(dir..'/ntp-address',address) then fail('Cannot write NTP listener address') end
 end
 if not probe and not fs.writefile(dir..'/lan-dns-mode',uci:get('strxwall','main','lan_dns')=='1' and 'managed' or 'unmanaged') then fail('Cannot write LAN DNS mode') end
 if not probe and not fs.writefile(dir..'/ntp-mode',ntp_enabled and 'proxy' or 'direct') then fail('Cannot write NTP routing mode') end
 if not probe then
  local function endpoint(v) return (resolvers.ipv6(v) and '['..v..']' or v)..':53' end
  local dnsserver=endpoint(policy.lan[1]);local dnslabel=policy.label..' · '..policy.mode
  fs.writefile(dir..'/dns-server2',policy.lan[2] and endpoint(policy.lan[2]) or '')
  if not fs.writefile(dir..'/dns-server',dnsserver) or not fs.writefile(dir..'/dns-label',dnslabel) then fail('Cannot write DNS resolver settings') end
 end
 if not fs.writefile(dir..'/udp-mode',udp) then fail('Cannot write UDP mode') end
 local data=json.stringify(config,true)
 if not data then fail('Failed to encode configuration') end
 if not fs.writefile(dir..'/config.json',data) then fail('Cannot write runtime config') end
 if arg and arg[1]=='--startup-debug' then
  config.log.loglevel='debug'
  local debug_data=json.stringify(config,true)
  if not debug_data or not fs.writefile(dir..'/config-check.json',debug_data) then fail('Cannot write temporary validation config') end
 end
 if not fs.writefile(dir..'/mode',mode) or not fs.writefile(dir..'/device',device) then fail('Cannot write runtime settings') end
end
local ok,err=pcall(build)
if not ok then
 fs.writefile(dir..'/error',tostring(err))
 io.stderr:write(tostring(err)..'\n')
 os.exit(1)
end
