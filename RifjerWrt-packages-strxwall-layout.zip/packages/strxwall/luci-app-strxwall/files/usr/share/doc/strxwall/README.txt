STRXWall 1.6.0 — standalone first release

An independent native LuCI JavaScript node manager, UCI configuration, procd service and nftables
TCP redirect implementation. No PassWall runtime files, settings, controller
routes or libraries are used. Your existing /usr/bin/strxcore is the engine;
it is not included or modified. LuCI and firewall4 are system dependencies.

INSTALL
System > Software > Upload Package: luci-app-strxwall_1.6.0_all.ipk.
This upgrades the earlier luci-app-strxwall dashboard add-on into a standalone
application. It does not replace or uninstall luci-app-passwall.
Log out and in; open Services > STRXWall.
Installation enables the boot service, but its configuration is disabled by
default, so no core starts and no traffic rules change on install or reboot.

SETUP
1. My nodes: Add, enter a name, protocol and connection details. Save & Apply.
2. Settings: Select your saved node. Start with Local proxy only.
3. Enable STRXWall and Save & Apply. Check Overview and Logs.
4. For LAN use, stop/disable your old PassWall and any other transparent proxy
   engine using their own controls. STRXWall never changes their settings.
5. Select LAN IPv4 TCP proxy; confirm the Linux LAN device (usually br-lan),
   then Save & Apply. LAN input policy must allow access to the redirect port.

PROTOCOLS AND CUSTOM CORE OPTIONS
Standard forms: VLESS, VMess, Trojan and Shadowsocks.
Transports: raw TCP, WebSocket, gRPC, HTTPUpgrade and XHTTP, optional TLS/SNI.
TLS certificate verification stays enabled. VLESS encryption defaults to none.
For REALITY, special STRX options, or newer protocol fields: select Custom,
then enter ONE complete Xray outbound JSON object, including protocol,
settings, streamSettings as needed. It is preserved, except tag becomes proxy.
Link import and subscriptions are described below. No automatic core updater yet.
Node creation, editing, removal and selection are implemented independently.

ROUTING SCOPE
Local mode provides router-local SOCKS5 127.0.0.1:10879 and HTTP 127.0.0.1:10880.
LAN IPv4 TCP mode captures public IPv4 TCP arriving on the selected device.
Optional LAN IPv4 + IPv6 TCP mode adds public IPv6 TCP interception through a
separate IPv6 redirect listener (12380); IPv4 continues using port 12379.
Router/local, private, IPv6 link-local/ULA/multicast destinations remain direct.
Core/router-originated traffic is not captured. UDP and LAN DNS retain normal
router routing. This is NOT a full-tunnel or DNS-leak-proof release.
Dual-stack LAN mode is opt-in: existing routing mode is preserved on upgrade.
Your router must already provide suitable IPv6 connectivity to LAN clients.
This package does not configure ISP WAN6, prefix delegation or DHCPv6/RA.
The selected proxy must also reach IPv6 destinations; an IPv6 server address
alone does not establish that. Kernel IPv6 NAT and custom-core support are
required and must be verified on the router.

SERVICE AND RECOVERY
/etc/init.d/strxwall start|stop|restart
Settings > Stop now stops the running process. To keep it stopped, clear
Enable and Save & Apply. Node edits take effect on service restart/apply.
LAN capture is installed only after the core config passes its own validation
and its redirect listener appears. Rules are removed on normal core exit and
service stop. When auto-switch is enabled, the supervisor can recover an unreachable or exited
core by testing and selecting an eligible backup. Invalid startup configuration
still needs manual correction. Otherwise inspect logs and apply to retry.
The core uses a separate inet strxwall nftables table. Restart STRXWall after
an external ruleset flush. Traffic is allowed to return to normal direct
routing when the service stops; there is no kill switch.
Emergency command: /etc/init.d/strxwall stop
If a hard crash left rules behind: nft delete table inet strxwall

FILES
/etc/config/strxwall — own nodes and settings, private permissions, opkg conffile.
/var/run/strxwall — private generated runtime configuration and validation output.
Logs: LuCI > Services > STRXWall > Logs, or logread -e strxwall.
No old PassWall nodes are automatically copied. Enter your own node details.
Removing luci-app-strxwall stops this service and removes its files; normal
opkg conffile retention applies. Your strxcore and old PassWall stay untouched.

VALIDATION
NEW IN 1.6.0
- Settings > Proxy-server connection: Automatic IPv4/IPv6, IPv4 only or IPv6 only.
  With system DNS, Auto uses the standard system dialer behavior. With an
  explicit DNS provider, Auto queries both families and configures Xray's
  Happy Eyeballs TCP address racing (250 ms, two concurrent attempts).
  Forced modes resolve only the chosen family; conflicting IP literals reject.
  Custom STRX core compatibility still needs verification on the actual router.
- Core DNS is no longer unconditionally IPv4-only. Its query strategy follows
  the chosen family. The fixed Cloudflare DoH address remains 1.1.1.1, so a
  router with no IPv4 reachability should select a resolver it can actually
  reach, such as correctly configured router system DNS.
- Active-node capability detection runs after startup, then caches for 15 minutes.
  Node credential/connection/DNS changes invalidate its signature. Disable it
  under Settings if desired. Detect IP on a node or Detect active node on the
  dashboard requests a manual check. A busy maintenance task must finish first.
- Detection starts temporary test cores using forced IPv4 and IPv6 server
  connection strategies and verifies HTTPS through each tunnel. It records
  IPv4 only / IPv6 only / Dual-stack / No working family as observed FROM THIS
  ROUTER. Missing local IPv6, DNS problems or a blocked test URL may cause failure;
  these labels do not claim that an unreachable server lacks an IPv6 address.
- A separate HTTPS request through a working test tunnel to api6.ipify.org checks
  IPv6 destination reachability. Only the boolean result is retained. The IP
  capability fields and IPv6-exit result are visible on Overview; node rows show
  capability and timestamp. Detection does not switch the active node.
- Optional dual-stack LAN TCP mode, IPv6 local exclusions, separate redirect
  listener and readiness checks for both required ports. UDP remains direct.
- Live latency can fall back to IPv6 hostname resolution, or prefer it for a
  node previously detected IPv6-only. Measurement-family label on Overview.
- Local generator, capability-classification/cache, UI and firewall-rendering
  tests pass. These are not live kernel nft or STRX network validation.

FEATURES FROM 1.5.3
- Renames the unquoted nftables chain redirect (a reserved keyword) to
  strx_prerouting. This addresses the exact parser error reported on nft 1.1.6.

FEATURES FROM 1.5.2
- Fixes a redirect-listener readiness check that only read /proc/net/tcp.
  Both IPv4 and IPv6 TCP tables are now checked, so dual-stack listeners listed
  in /proc/net/tcp6 are recognized. Dashboard TCP status uses the same helper.
- Retains the readiness requirement; it does not bypass it or assume success.
- Listener failures record socket diagnostics; nft command output is captured
  separately. Both diagnostics are available in the Logs page.
- Local shell tests cover IPv4, IPv6-only, wrong state/port and missing tcp6.
  The user's actual socket table has not been inspected, so this correction is
  not a confirmed diagnosis of their startup failure. Generic STRX connection
  test error (13) remains undiagnosed.

FEATURES FROM 1.5.1
- Fixes the maintenance crash reported on the user's router: nixio.fs.mkdir
  receives octal mode strings ("700"), not decimal 448. umask is "077".
  Regression mocks now require these exact mode formats.
- Supervisor sends TERM to all children first and bounds cleanup to 3 seconds
  before KILL. A local process test confirmed a TERM-resistant child does not
  leave the wrapper waiting indefinitely. Firewall rules are removed first.
- WebSocket Host is generated as wsSettings.host. For imported custom JSON,
  legacy headers.Host is moved to host in the runtime config, preserving other
  headers and custom options. Stored node JSON is not destructively rewritten.
  WebSocket itself is retained: XHTTP requires a compatible server configuration.
- Settings > Core DNS resolver offers system, Cloudflare DoH, Cloudflare UDP,
  Google, Quad9 and custom IPv4 DNS. System remains the default unless selected.
  Cloudflare DoH uses https+local://1.1.1.1/dns-query to bootstrap directly.
  Non-system choices set the core's built-in DNS and ForceIPv4 sockopt strategy
  for the proxy-server hostname. Existing unrelated sockopt fields are preserved.
  Main and temporary test cores use the same DNS selection.
- This does not change dnsmasq, LAN DNS, router diagnostics or subscription DNS.
  Destination names sent to the remote proxy may still be resolved remotely.
- The custom core's generic 'connection test failed' / ret (13) is not diagnosed
  by these logs. Successful startup or accepted SOCKS requests do not prove a
  working tunnel. DNS is only one possible cause; no guaranteed fix is claimed.

FEATURES FROM 1.5.0
- Overview now includes Choose nodes for auto switch: a searchable checklist,
  select-all/clear controls, selected/backup counts and an enable switch.
  Save auto switch writes the exact backup pool without changing the active node.
  Existing health-check thresholds, cooldown and tunnel verification still apply.
- Only selected nodes are eligible for failover. Include the current node too
  if you want it eligible again after a later switch. Enabling requires at least
  one selected alternative to the current active node.
- After saving an explicit pool, new link/subscription imports stay ineligible
  until selected. Node-copy defaults to ineligible; newly created manual nodes
  have an explicit checkbox to join. Previously eligible nodes are preserved
  on upgrade until you save a new pool. Node-editor eligibility changes remain
  another way to edit the same pool.
- Backup selections and the enable toggle are not reset by background polling.
- Shared interface styling refreshed with cyan/violet/teal/amber accents,
  gradient panels, color-coded status cards and emphasized live-latency values.
  No external graphics, fonts, scripts or UI framework dependencies were added.
- Tests cover exact pool persistence, invalid-pool rejection without partial
  writes, preventing new imports from silently joining, and UI pending edits.

FEATURES FROM 1.4.0
- Live ICMP ping and TCP connection latency for the active node on Overview.
  Nominal sample interval is 5 seconds. Slow requests are not overlapped.
- My nodes now has separate Ping, TCPing and URL test columns. Live sampling
  checks up to two matching nodes per 10-second batch, rotating through the
  current group/search results. A Ping action measures a row immediately.
- Pause toggles on both pages. Hidden tabs do not start new latency requests.
  Sampling only runs while the corresponding page is open. No cron task added.
- Ping is one ICMP echo with a bounded timeout. TCPing is a TCP connect-only
  request to the server port; no HTTP payload or TLS credentials are sent.
  URL test remains the separate proxy-tunnel HTTPS check from earlier releases.
- These readings measure router-to-node server latency, not the public exit-IP
  geolocation service or browser-to-router latency. ICMP blocking can cause
  Timeout while TCP and the proxy tunnel still work.
- Hostnames resolve to IPv4 with a 2-second DNS timeout for these diagnostics.
  IPv6 literals are attempted directly; ICMP availability depends on router ping.
  Nodes without a simple server endpoint show Unavailable instead of fake values.
- Additional runtime dependency: resolveip. Existing node configuration preserved.

FEATURES FROM 1.3.0
- Main dashboard rebuilt around a distinct connection-identity / quick-controls
  layout, service summary cards and a website-connectivity panel.
- Manual public-IP, approximate city/country and ISP lookup through ipwho.is.
  The public IP is hidden by default, including after a lookup; Show IP reveals
  it locally. Lookup results remain in page memory, not in STRXWall logs/config.
  No IP lookup is run automatically. Clicking Check IP & location contacts the
  external HTTPS geolocation service through the selected diagnostic route.
- Diagnostic route selector: router direct or STRX SOCKS tunnel. It affects only
  IP lookup and website checks, not the configured routing mode. The displayed
  IP is the exit IP of that requested route, not a guarantee about all traffic.
- Google, GitHub, YouTube and Alibaba Cloud HTTPS checks, individually or all.
  A 200-399 response counts as success; other HTTP responses are shown as such.
  Displayed latency is HTTPS request duration, not ICMP ping or bandwidth.
  Third-party availability/rate limits can affect these diagnostic results.
- Main enable switch and active-node selector directly on the dashboard; Apply
  connection preserves advanced settings. Polling does not replace pending edits.
- UDP shown as direct and DNS as router system. No false UDP/DNS/HAProxy running
  indicators are displayed for features this application does not implement.
- Existing nodes and configuration remain opkg conffiles across upgrades.

FEATURES FROM 1.2.0
- Entire UI rebuilt as native LuCI JavaScript views. The old CBI form causing
  the nil section import crash is no longer used. Menu/ACL cache is refreshed.
- New node table with group chips, search, optional address display, active node
  indicator, Use/Copy/Edit/Delete actions and selected-node deletion.
- Add via link popup with a group name, plus a dedicated full-page importer.
- Node test uses a separate temporary core; reports HTTPS tunnel elapsed time,
  not ICMP ping. It does not switch the active node. Tests share a maintenance
  lock, so test one node at a time when maintenance is idle.
- Settings, subscriptions, overview and logs use the same new visual layout.
- Startup action checks service registration: starts an unregistered service
  instead of issuing restart/delete on the first enable.
- Copy produces a manual node independent of its original subscription.
  Deleting the active node stops/disables STRXWall until another is selected.
- Subscription imports are grouped by source name.

FEATURES FROM 1.1.0
- Import links: VLESS, VMess, Trojan, Shadowsocks. One per line, or a plain/base64
  link-list body. Exact duplicates within the same source group are updated.
- Imported nodes use Custom outbound JSON, so their imported transport/security
  fields remain editable. Standard REALITY links use current Xray field names.
  Unknown link options and Shadowsocks plugins are rejected; use custom JSON.
- HTTPS subscription URLs with manual and scheduled refresh. Plain/base64 link
  lists only; Clash YAML and arbitrary JSON subscription formats are unsupported.
  Save source URL before clicking Refresh saved subscriptions. Logs show results.
  Refresh adds/updates only; it keeps old nodes, including disappeared entries.
  Manual nodes and each subscription have separate duplicate groups. URLs and
  credentials are stored privately. Downloads try direct, then the active SOCKS.
  Failed scheduled attempts back off until the next interval; Refresh now retries.
- Automatic failover: Settings > Automatic switching. Default active-tunnel test
  is HTTPS gstatic generate_204, through local SOCKS with proxy-side DNS lookup.
  Select another stable HTTPS URL if that URL is blocked in your environment.
  Responses 200-399 count as success. Default interval is 60 seconds, threshold
  3 failures and cooldown 180 seconds. At least two nodes are needed for failover.
  Backup testing uses a temporary core with SOCKS port 10881 and HTTP port 10882.
  Only a verified backup is selected. No working backups means no node change.
  This is failover, not fastest-node load balancing. At most 20 backups are tested
  per pass, rotating through larger pools. Tests may take longer than the interval.
  Disable Allow automatic switch on nodes you want excluded from the backup pool.
  Subscription scheduling and auto checks run while STRXWall service is running.
- Requires curl with SOCKS/HTTPS support and ca-bundle, declared IPK dependencies.
- Upgrade preserves existing configuration; after installation use Save & Apply
  in Settings to run the new supervisor. Core binary is not updated or replaced.

FUTURE WORK (NOT IMPLEMENTED IN THIS RELEASE)
UDP/TProxy and IPv6 routing; proxy DNS; per-device policies; fastest-node selection;
QR import/export; Clash-format subscriptions; traffic graphs and quota display;
core binary upload/update with validation. These are not claimed as working yet.

Local tests checked Lua and template-Lua syntax, shell syntax and JavaScript
syntax. Mock UCI tests covered generated outbound structures for five node
modes, five transports, TLS verification, redirect inbound setup, custom field
preservation and rejection of invalid ports/devices/nodes/JSON.
Importer tests covered supported link formats, encoded credentials, IPv6 hosts,
REALITY mapping, duplicate handling and unsupported options. Mock maintenance
tests checked thresholds, verified failover, cooldown, eligibility, all-backup
failure and retaining nodes on subscription failure.
New API tests covered own-configuration isolation, validation, node copy and
delete, subscription URL validation, and first start versus restart selection.
A DOM harness rendered all six UI views and exercised link import, modal node
editing, filtering, settings, dashboard quick controls, manual-only lookup,
IP conceal/reveal and four website checks. Mock API tests checked both diagnostic
routes and fixed network-target validation. ICMP/TCP measurement parsing,
errors/timeouts, live reading display and hidden-page sampling pause were tested
with mocks/harnesses. Real ping/TCP timing on the router remains untested. No real browser rendering
was available for layout validation.
Package directory order and metadata were checked. No nft/kernel execution,
AW1000 runtime test, network end-to-end test, or strxcore binary execution was
possible here. Actual core compatibility must be checked on the router.

1.6.1: Fix leaked temporary probe cores. Cleanup matches strxcore executable and exact probe config argument, including orphaned/forked processes; runs before/after probes, after Lua errors, and on service start/stop. The main config and other proxy services are excluded. Background detection defaults off for new installs; existing configuration is preserved. This release does not change LAN DNS forwarding.

1.6.2: Optional service-managed LAN DNS via dns2socks and Cloudflare TCP DNS over local SOCKS. New Settings toggle; dashboard status and DNS diagnostics. Loopback UDP 1054, independent from temporary manual 1053. Waits for listeners before changing primary dnsmasq forwarding. Saves only server/noresolv in a private persistent backup; restores on stop, failure and next boot after an unclean shutdown, preserving unrelated DHCP configuration and external forwarding changes. DNS helper exit stops the tunnel safely. Explicit core resolver required to prevent bootstrap loops. IPv4 and IPv6 DNS answers are forwarded. This does not add general UDP proxying or enable WAN IPv6. Backup: /etc/strxwall-dns-backup.json. Run /usr/libexec/strxwall-dns restore for manual recovery. Existing LAN DNS settings are unchanged until enabled.

1.6.3: Fresh-install defaults match the verified setup: LAN IPv4 + IPv6 TCP routing, br-lan, warning log level, Cloudflare DoH for node-server DNS, automatic IPv4/IPv6 server connections, LAN DNS through the tunnel, and automatic IP-family detection. Auto-switch remains off until a backup pool is selected. No node or credentials are bundled. Fresh installations remain disabled until a node is selected and the user enables the service. Upgrades preserve the existing UCI configuration.

1.7.0: Compact dashboard. Node latency and website connectivity share one live monitor. Node ICMP/TCP every 5 seconds; website rounds every 15 seconds, maximum two concurrent website requests and no overlapping rounds. Hidden tabs pause probes. Website success cards pulse only with a recent successful result (45-second freshness limit) while live updates are enabled. Paused, stale or failed results do not pulse; reduced-motion settings disable animation. Route/node/service changes invalidate old results. IP lookup remains manual. Removed subscription page, menu/API and refresh jobs; existing saved nodes/configuration are retained. Removed native Overview menu title to avoid duplicate Overview tabs while keeping its route and custom navigation.

1.7.1: Monitor route always defaults to Through STRX tunnel, including when stopped. Node latency now refreshes every 15 seconds; websites remain every 15 seconds. Proxy exit-country badge in the live monitor: local vector flags for Malaysia, Singapore and Indonesia; country-code fallback elsewhere. Looks up exit country through the active SOCKS tunnel on dashboard load, then every 5 minutes; retries failures after 60 seconds and pauses when hidden or live updates are off. Country lookup returns no IP/ISP fields, and the separate IP reveal remains manual. Node/service changes invalidate country results; router-direct diagnostics do not change the proxy flag. Country location is approximate; unavailable detection shows Unknown country.

1.8.0: Unified LIVE CONNECTION MONITOR contains active node/service controls, proxy flag, node ICMP ping, current website-check count, LAN DNS and routing status, private IP/location/ISP lookup, live website cards and expandable runtime details. Removed Node TCP and IPv4/IPv6 capability block from the dashboard; dashboard latency requests skip the unused TCP probe. Capability tests remain available in My nodes. ICMP and website checks remain every 15 seconds with hidden-tab pause, bounded website concurrency and freshness-aware success animation. Preserves manual IP lookup/reveal and protects it against results from a previous route/node. Auto-switch pool remains below the monitor. No traffic statistics are invented; core-running status and website success are displayed separately.

1.8.1: Proxy exit identity is automatic on dashboard load, node/service/diagnostic-route changes and every five minutes. No Check IP & location button is needed. Failures retry after 60 seconds. Live pause and hidden tabs suspend automatic lookups. One request at a time; stale results are ignored and a new identity is fetched after an in-flight route/node change. Tunnel identity supplies the country badge too, avoiding duplicate geolocation requests. Show/Hide IP remains; a changed IP is masked again. The global Refresh now control can refresh identity immediately.

1.8.2: Keep one navigation row: STRXWall's own Overview / My nodes / Import links / Settings / Logs links. Native LuCI child routes remain routable but have no menu titles, preventing automatic duplicate tabs. Theme fallback CSS hides duplicate tab containers only on STRXWall pages. Footer credit: Created by Faris. Existing configuration and core binaries are unchanged.

1.9.0: Automatic STRXCore → standard Xray fallback (/usr/bin/strxcore, /usr/bin/xray), with explicit Settings core selector. Main run, validation, maintenance probes and version reporting use a common exec wrapper. Missing core blocks startup before interception. Both core types have probe cleanup. Standard Xray must support the node's transport/security fields; STRX-specific features are not emulated. Dashboard command-center layout based on supplied reference: schematic world route card, real CPU/RAM and measured LAN traffic history, live website cards, compact node/identity/status row and backup pool. Traffic uses configured LAN interface counters, includes all LAN traffic, and labels it accordingly. CPU and rates need two samples; missing/reset counters show unavailable/collecting instead of invented values. Updates pause when hidden or live mode is off. Country and website results remain measured; UDP remains direct. Neither core is bundled; offline installs require dependencies and a compatible core already installed.

2.0.0: UDP Node choices Direct / Same as TCP / Block public UDP. Same as TCP adds Xray/STRX UDP transparent listeners (12381/12382), nft TPROXY and fwmark policy routes. IPv4 mode covers IPv4 UDP; dual mode covers both families. Loopback, local, private, multicast and reserved destinations bypass interception. Firmware must provide nft TPROXY and IP policy-routing support; startup validates nft rules before adding routes and refuses occupied reserved route tables 10531/10532 or rule priorities 105/106. Uses mark 0x53570000/0xffff0000; preserves lower mark bits. Startup failure rolls back owned rules/routes; stopping removes only owned entries. Core UDP support is checked using a bounded UDP DNS request via a dedicated loopback core inbound (10885) to Cloudflare DNS, once per minute while the dashboard is live. This verifies node UDP forwarding, not every LAN application's UDP path. UDP remains Direct on upgrade until selected explicitly.
DNS: IPv4/IPv6 and custom literals for node resolution and LAN tunneled DNS separately. IPv6 node resolvers need router IPv6 connectivity; tunneled IPv6 resolvers need exit-node IPv6 connectivity. IPv4 DNS can return AAAA answers. AdGuard LAN DNS presets offer upstream ads/tracker filtering.
Ad blocker: optional dnsmasq starter list (30 domains), custom block list and allow list (up to 3000 domains per list, 45 KB each, total API request 60 KB). Uses dnsmasq extraconftext support; does not replace unrelated extra configuration. Applies to clients using router DNS; encrypted/alternate DNS and same-domain ads can bypass it. Allow-list rules override local rules but cannot undo upstream resolver blocking. Original extra config is restored on stop, including preservation of independent edits. Local rule count shown on dashboard is not a blocked-query counter. No automatic blocklist downloads or subscriptions. Ad blocking stays off on upgrade until enabled.
Validation: Lua/API/config/DNS restoration tests, domain/IP validation, IPv4/IPv6 firewall rendering and failure rollback fixtures, bounded UDP helper, UDP status UI, and existing service regression checks. Live router nft TPROXY/kernel and remote-node UDP validation are still required; no router execution was performed here.


2.1.0 (current): AdGuard DNS override replaces the removed local-rule blocker.
Main dashboard has accessible ON/OFF switches, independent core and proxy
connectivity states, and Start/Stop/Restart with progress and failure feedback.
Traffic & Performance and its telemetry polling are removed. Website, identity,
country, UDP and ping monitoring remain; proxy connectivity runs every 15s
while Live updates is enabled. A successful HTTPS request through the active
SOCKS tunnel confirms connectivity; two failed tunnel requests show disconnected.
Unexpected HTTP responses or unavailable checks are inconclusive, never green.
All status checks pause in hidden tabs; paused/stale status is distinguished.

DNS upstream IP mode: IPv4, IPv6 or dual. This selects actual provider IPs,
independent of the proxy-server connection family. Both A and AAAA records
remain supported (core queryStrategy UseIP). Dual LAN DNS runs two supervised
dns2socks forwarders on loopback 1054/1055, one upstream of each family;
dnsmasq uses both and restores its prior server/noresolv settings on stop/failure.
Core bootstrap uses direct TCP local DNS for literal resolvers, avoiding UDP
blocking and recursion through a proxy whose hostname is not yet resolved.
Cloudflare DoH remains DoH. DNS IP mode requires explicit providers; custom
addresses support matching single-family modes only. Node-server IPv6 DNS needs
router WAN IPv6; tunneled LAN IPv6 DNS needs IPv6 at the proxy exit. This does
not enable WAN IPv6 or guarantee IPv6 reachability.

AdBlock ON snapshots STRXWall DNS preferences in the UCI conffile before
activating AdGuard for both core bootstrap and LAN tunnel DNS; it also enables
LAN DNS forwarding. Snapshot persists across restarts and upgrades. Repeated
ON never replaces it. OFF restores the original preferences, including absent
options. The dashboard restarts a running service when toggling; while stopped,
preferences are saved for the next start. DNS provider edits are disabled during
the override; DNS IP mode may still be selected. The pre-override mode returns
on OFF. Existing nodes and unrelated settings are untouched. Legacy local rules
are no longer applied; legacy dnsmasq backup restoration remains supported.
This uses AdGuard public filtering DNS, not AdGuard Home. Encrypted/alternate
client DNS and same-domain ads can bypass DNS filtering.

Verification: generator output for all resolver families and dual AdGuard,
persistent snapshot and exact restoration, dual dnsmasq forwarders and old-rule
recovery, service control success/failure/locking, proxy result classification,
UI action progress, duplicate suppression and pause behavior, and supervised
DNS process lifecycle fixtures. No live router/core/kernel or browser visual
rendering was performed; router verification is required after installation.

2.1.1: Monitoring runs automatically every 60 seconds; Live updates switch removed.
Identity and country refresh every minute too. Hidden tabs pause checks. A known
proxy state remains visible during background checks; initial checks show Checking.
Stale results expire after 150 seconds; failures/inconclusive results still update.
Bundled ARM64 core copied byte-for-byte from user-supplied xray-core IPK into
/usr/libexec/strxwall/strxcore. No xray init/config files are installed. Auto selects
existing /usr/bin/strxcore, then bundled core, then /usr/bin/xray. Explicit bundled
selection is available. Package architecture aarch64_cortex-a53; not portable to
other CPUs. Uploaded package metadata says 25.12.2-strx_ws_0.1.6 despite its filename
26.2.6; binary could not be executed on this x86 host. Original binary SHA256:
621a3f9793cdafd355b1ceb9ad1fd7a31f59d02ecea2ee379bd478ee37ea62cc

2.2.0: Compact dark connection console. Slim proxy/core/node status strip;
one active-node card with country, ICMP latency and private exit identity beside
compact website checks. Removed decorative map. Enable STRXWall, AdBlock,
DNS upstream mode and Start/Stop/Restart share one control row; restart is an
accessible icon button with tooltip. DNS mode validates the actual resolver
configuration before saving; invalid custom-address combinations preserve the
previous mode. Running services restart after DNS mode/AdBlock changes.
Backup pool and runtime details are collapsible; collapsed pool shows backup
count and auto-switch state. Native details elements retain their open state
during polling. Existing nodes, core selection and DNS preferences are preserved.
Monitoring remains automatic every minute, with hidden-tab pause and steady
proxy success during background checks. Bundled ARM64 core is unchanged.
Validation: UI DOM interactions, DNS-mode commit and rejection rollback, service
and DNS regression fixtures. No browser visual or live router test performed.


2.3.0: Lightweight health and recovery tools.
* Dashboard TCP, UDP and DNS indicators are independent. DNS A/AAAA checks use
  example.com through primary router DNS only when dnsmasq points to STRXWall's
  managed forwarders. Each query is capped at four seconds; checked once per
  minute while dashboard is visible, cached 55 seconds. No-record, unavailable,
  timeout and changed-forwarder states are distinguished. Cached DNS answers
  do not prove current upstream reachability or IPv6 internet access.
* HTTPS curl diagnostics capture exit status: DNS resolution, timeout, unreachable
  proxy/destination, TLS handshake/certificate and proxy rejection reasons.
  Two failed tunnel targets confirm check failure; unexpected HTTP responses or
  unavailable checks stay inconclusive. Compact Diagnostics modal combines core,
  firewall, TCP/UDP, A/AAAA DNS and failover status without exposing credentials.
* Auto switch keeps existing thresholds and cooldown. Small HTTPS HEAD requests avoid downloading pages. A second active HTTPS
  target avoids switching just because the first target is unavailable. Backups
  must pass two HTTPS targets in one temporary core. Only three sequential
  candidates per pass; large pools rotate between passes. Re-checks active node,
  enabled state, backup eligibility and auto-switch setting before committing.
  Last switch time/reason and active failure count are exposed in runtime details.
  Automatic family probing is deferred while failover failures are accumulating.
* Password-encrypted backup/restore via browser Web Crypto, requiring HTTPS.
  PBKDF2 SHA-256, 600000 iterations, random 16-byte salt, AES-256-GCM, random
  12-byte IV and authenticated format marker. Password never goes to router.
  File contains encrypted STRXWall main and node sections only; neither core
  binary nor other applications are backed up. Configuration limit 512 KiB.
  Wrong password/tamper rejects before upload. Restore preview shows node count;
  explicit confirmation then replaces own configuration atomically, retaining a
  private /etc/strxwall-before-restore recovery copy. Restored service is stopped
  deliberately; review nodes then start. Plain staging is private to root and
  expires after five minutes when dashboard is accessed. Parser validation uses
  the UCI CLI in an isolated directory/package, not luci.model.uci directory
  arguments (modern LuCI ignores those). No additional crypto packages required.
Validation: API/schema/restore rollback fixtures, real browser-compatible crypto
round trip and tamper/wrong-password tests, backup UI workflow/UTF-8 upload,
bounded DNS helper subprocess fixtures, failover endpoint/selection-race and
candidate-cap tests, existing core/service checks and UI DOM harness. No live
router, native UCI parser or browser visual rendering was available on this host.
Existing nodes, DNS preferences and bundled ARM64 binary are unchanged on upgrade.

2.3.1: Removed TCPing and URL test columns and URL test buttons from My nodes. Node latency requests now use ICMP only, avoiding unused TCP probes. Live ping, node management, IP detection and background failover checks remain available.

2.3.2: Fix observed maintenance line-43 crash: temporary cores are launched via
sys.call with stdin/stdout/stderr redirected and their PID written to a private
file. No PID is read from sys.exec background output. Missing/invalid PIDs fail
with a diagnostic and bounded cleanup. Maintenance/API command-output reads
handle nil as an unavailable result instead of indexing nil.
LAN DNS readiness now uses the shared listener helper for both IPv4 and IPv6
kernel tables. DNS helper-exit, listener-readiness and dnsmasq-apply failures have
separate messages. DNS helper endpoints and dnsmasq restart output are captured
in DNS logs; temporary core validation/runtime output is exposed in Logs.
Diagnostics now distinguishes the actual SOCKS listener from the service wrapper
so a surviving maintenance process does not count as a running core.
The reported DNS startup failure's exact cause requires router DNS logs; this
release does not assume it was caused by IPv6 or change the user's DNS choices.
Validation: nil-output and missing-PID maintenance regressions, API/config/UI
checks, DNS lifecycle fixtures and dual-family listener tests. Router test pending.

2.3.3: Temporary probes wait up to eight seconds for their SOCKS listener instead
of assuming readiness after one second. Every probe records a structured
result.json with node, family, stage, reason and time, and logs candidate-specific
failures. Generation, validation (including exit status), PID launch, listener
startup, primary HTTPS and second-target verification are distinguished.
Each probe clears stale generation/runtime files. Detection skips impossible
forced-family tests for literal server IPs; a failed probe setup is labelled
Test unavailable rather than No working family. Prior cached detection results
are invalidated by a probe signature version. An empty backup pool is reported
separately. No bypass of backup verification or forced switch to an unhealthy
node was added. The user's empty runtime log does not by itself establish the
cause of the failed probes; the new per-stage result is needed on the router.
Validation covers delayed readiness, readiness deadline, literal IPv4/IPv6
skips, missing PID, nil output and generation/validation errors. Live router
backup switching remains unverified. Nodes/settings/bundled core preserved.

2.4.0: Automatic return to the previous node is enabled by default when automatic
switching is enabled. After failover the original node is remembered while the
backup serves traffic. At most once per minute, one temporary core verifies two
HTTPS targets. Three consecutive successful recovery checks and the existing
switch cooldown are required before proactive return. A failed recovery resets
the counter. Disabled service/auto-switch/auto-return prevents return. Manual
node selections cancel the pending target, including an explicit same-node
selection made during a recovery probe. Deleted targets are discarded.
The original target is retained through a chain of backup failovers; ordinary
emergency failover still uses its existing verified-backup rules when the active
backup fails. Reaching the remembered node through emergency failover clears the
pending return. Automatic IP-family detection is deferred during recovery checks
to avoid launching unnecessary probes. Target IDs are saved with the auto-selected
backup in UCI so recovery can resume after restart/reboot; consecutive success
counts reset after reboot. An existing recorded failover can supply the target
when upgrading. Completed return clears the target and logs a return event.
Backup-pool controls and Settings include Return to previous node. Runtime details
show target, recovery progress and last-switch reason; collapsed pool shows progress.
No nodes, credentials, routing or DNS choices are replaced on upgrade.
Validation covers three successes, failed-check reset, one-minute rate limit,
cooldown, disabled return, deleted target, manual selection during recovery,
recorded-failover migration and reboot target recovery. Existing failover/core/UI
checks pass. Actual router automatic return remains to be verified.

2.5.0: Visible dashboard recovery status, ordered fallback and switch refresh.
Recovery strip shows the selected/active node, previous-node recovery progress,
paused return or cooldown wait, and the last automatic switch/return time.
The backup pool has numbered priorities and accessible up/down controls. Save
stores an independent UCI failover_order list; eligibility is still explicit.
Maintenance follows this sequence, skipping the active/unselected/deleted nodes.
At most three sequential candidates are tested per pass; remaining entries are
continued next pass. A healthy tunnel or sequence change resets the cursor.
Edits to the saved sequence during a probe defer selection to the next pass.
Successful core startup publishes active-node and active-core.pid only after
listeners, firewall and managed DNS are ready. Cleanup and core exit remove
readiness markers. Dashboard reads a small local switch_status endpoint every
five seconds while visible; no internet requests or core version commands run
in this status poll. Scheduled connectivity checks remain once per minute.
When the new node is ready, node/identity/country/website/TCP/UDP/DNS results
refresh automatically. Old in-flight results are discarded and rechecked for
the new generation. Hidden tabs pause polling. Pool order edits and open details
remain intact during status updates; the whole browser page is not reloaded.
Existing nodes, settings, automatic return and bundled ARM64 binary are preserved.
Validation: ordered priority selection, exclusion, multi-pass budget, sequence
edit race, API order validation, ready-marker semantics, UI reorder persistence,
visible recovery counters, pending-switch suppression, automatic failover/return
refresh, hidden-tab pause and supervisor marker cleanup. Router verification and
browser visual rendering remain pending.

2.5.1: App title uses a scoped div instead of the HTML header element, avoiding global LuCI theme header positioning. App heading stays in normal document flow; native router header remains above it. Expanded fallback sequence has no internal height cap or scrolling; all matching nodes are visible. Routing, DNS, nodes and automatic switching are unchanged. UI DOM checks passed; actual theme rendering requires router verification.

2.5.2: Encrypted backup and restore work over HTTP with bundled SJCL in a browser worker; AES-256-GCM/PBKDF2 format remains compatible. Passwords stay in the browser. HTTP does not protect the LuCI session or page delivery.

2.5.3: Mobile touch targets, wrapping navigation, responsive node cards, compact controls and fallback ordering; footer credit Created by Tuan Faris.

2.5.4: Recover orphaned dns2socks helpers only when executable, parent and STRXWall SOCKS/listener arguments match. Preflight UDP 1054/1055 conflicts; preserve other listeners and report socket details. Reset DNS diagnostics per helper startup. Does not change Xray outbound configuration.

2.5.5: Serialized runtime startup/shutdown. DNS automatically skips occupied ports (1054/1055, then 11540–11559); retries failed binds. Forwarding and diagnostics use selected ports. Backup records exact forwarding targets for recovery after reboot; legacy backups remain supported. Other services are never terminated to reclaim DNS ports.

2.5.7: Record running state before future opkg upgrades and restore after successful configuration. Stopped/disabled services remain stopped; offline image installation does not start services. For the first upgrade from older packages use installer 1.3.0, which records state before old prerm runs. Direct upgrades from old hooks cannot recover state already lost by those hooks.

2.5.8: Fresh-install defaults: LAN IPv4 TCP routing, IPv4 proxy-server connections, IPv4 DNS upstreams, and UDP Node = Same as the TCP node. Existing UCI configuration remains preserved by opkg. Local-only/probe modes retain direct UDP when no explicit UDP setting exists. No changes to router WAN/LAN IPv6 configuration or bundled cores.

2.5.9: Rebuilt all IPK layers as portable USTAR with integer timestamps and no PAX extended headers, fixing old opkg errors Unknown typeflag 0x78. UI version labels aligned with package version. IPv4/UDP defaults and upgrade runtime-state hooks retained.

2.5.10: UDP Node defaults to Direct connection for fresh installs and missing settings. Same as TCP remains available. Existing saved UDP settings are preserved. IPv4 defaults and Xiaomi opt-in boot startup remain unchanged.

2.5.11: Manage explicit opkg HTTP/HTTPS proxy through 127.0.0.1:10880 after listener readiness. Shared /etc/opkg.conf affects terminal and LuCI Software. Default opt-in setting on; stop/boot recovers saved proxy directives, preserving other config lines and feeds. Unsupported old opkg binaries leave configuration unchanged and log diagnostics. Environment proxy/no_proxy overrides can still affect callers.

2.5.12: Fix nixio.fs.chmod compatibility: use octal mode string 600, check result before committing opkg config/backup.

2.5.13 V1 TEST: HTTPS-backed IPv4 NTP on UDP1123, redirects LAN and router UDP123 only after two authenticated HTTPS Date headers agree. Uses HTTP10880; no insecure TLS fallback. Does not modify sysntpd or system timezone. Stops intercepting after two hours without fresh time. Set strxwall.main.time_helper=0 to disable and restart. IPv6 NTP is not intercepted. Core must already be usable; an extremely wrong boot clock can prevent TLS bootstrap. HTTPS time has second-level precision, not NTP-grade accuracy. Android devices may also use vendor-specific time services; hardware testing required.

2.5.14 V1: Settings button Use Malaysia NTP configures system sysntpd with 0.my.pool.ntp.org and two Asia fallback pools, timezone Asia/Kuala_Lumpur. Direct UDP123, persistent system configuration independent of proxy. Removes previous experimental HTTPS time daemon; existing NTP configuration changes only when user presses the button. No claim of synchronization based solely on service restart. Does not configure Android vendor NTP or intercept LAN NTP.

2.5.15 V1: Automatically configure persistent Malaysia/Asia NTP and Kuala Lumpur timezone during live installation/upgrade. Enable and restart sysntpd; no Settings button required. Sync continues through sysntpd after reboot, independent of STRXWall/proxy. No offline image system changes. Setup failure logs a warning without breaking proxy installation; actual synchronization still requires direct NTP reachability.

2.5.16 V1 TEST: With UDP Direct/Same in LAN mode, public IPv4 UDP123 from LAN and router is DNATed to a dedicated LAN-bound UDP listener and forwarded to 0.my.pool.ntp.org:123 through a marked copy of the active proxy node. Non-NTP UDP remains Direct when Direct selected; old saved Same selection is preserved. Block mode has no NTP exception. Proxy UDP support is required. Private/local NTP and IPv6 NTP are unchanged. ntp_proxy=0 disables exception after restart. High mark 0x53580000 prevents recursion and preserves mwan3 mark-bit space; listener and rules follow runtime lifecycle. No HTTP-derived clock or local fake NTP server. NTP forwarding is only ready after listener detection, not a claim of successful sync.

2.5.17 V1: Default LAN IPv4 routing, IPv4 proxy-server connection and UDP Same as TCP, matching user-confirmed Netflix/TikTok/NTP success. One-time live postinst migration routing_profile=ipv4_udp_v1 updates those three LAN settings before service restoration; preserves node/DNS, enabled state and later user choices. Existing Local-only mode is left unchanged. Dual-stack remains an explicit advanced option, not claimed repaired. No app-specific Netflix/TikTok bypass. Existing NTP-only routing and Malaysia NTP automatic setup retained.

2.5.18 V1 TEST: Fix ordering conflict between LAN UDP TPROXY and later firmware DNS hijack. When LAN DNS through tunnel is enabled, UDP53 bypasses TPROXY/Block and is redirected to local dnsmasq for both IPv4/IPv6; dnsmasq keeps using managed dns2socks. Disable managed DNS to retain previous UDP53 policy. Install traffic interception only after managed DNS helpers are ready. This removes a path that could proxy a rewritten private router DNS address. IPv4 working profile remains default. IPv6 proxy egress and TLS failure are not yet confirmed repaired; require hardware tests after DNS readiness.

2.5.19 V1 TEST: Independently owned inet strxwall_ipv6_guard forward chain (-10) rejects IPv6 packets from configured LAN that would leave through an unlisted interface, including direct WAN. Same-LAN forwarding and explicitly trusted VPN interfaces pass to existing firewall policy. TCP REDIRECT and UDP TPROXY go to local INPUT and remain usable. INPUT/OUTPUT, NDP/DHCPv6 and IPv4 are unchanged. Guard applies while enabled in LAN modes, survives core cleanup/restart and fw4 reload through owned script include; disabled/local mode or package removal removes it. Clear IPv6 conntrack on apply to tear down old bypassing flows; vendor NSS/ECM behavior still requires physical leak testing. Does not claim system-wide/router-originated IPv6 blocking. VPN interfaces must be actual trusted tunnels; a WAN name in that list would explicitly bypass protection. Existing working IPv4 profile, nodes/DNS and cores unchanged.
